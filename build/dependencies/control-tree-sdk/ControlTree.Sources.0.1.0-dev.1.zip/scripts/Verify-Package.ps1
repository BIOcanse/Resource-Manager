#Requires -Version 7
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$Package,
    [ValidateRange(1,1000000)][int]$MaxFiles = 10000,
    [ValidateRange(1,4096)][int]$MaxDepth = 64
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
try {
    $packageRoot = [IO.Path]::TrimEndingDirectorySeparator([IO.Path]::GetFullPath($Package))
    $manifestPath = Join-Path $packageRoot 'manifest.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
    $listed = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    $fileIndex = 0
    $bytes = 0L
    while ($fileIndex -lt $manifest.files.Count) {
        if ($fileIndex -ge $MaxFiles) { throw 'Manifest file limit exceeded.' }
        $file = $manifest.files[$fileIndex++]
        if (-not $listed.Add($file.path) -or $file.path -eq 'manifest.json') { throw 'Duplicate or self-referencing manifest entry.' }
        $path = [IO.Path]::GetFullPath((Join-Path $packageRoot $file.path))
        $relative = [IO.Path]::GetRelativePath($packageRoot,$path).Replace('\','/')
        if ($relative -cne $file.path -or $relative.StartsWith('../',[StringComparison]::Ordinal)) { throw 'Manifest path escaped or is not canonical.' }
        $item = Get-Item -LiteralPath $path -Force
        if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Manifest entries must be ordinary files.' }
        if ($item.Length -ne $file.length) { throw "Length mismatch: $relative" }
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $file.sha256) { throw "SHA-256 mismatch: $relative" }
        $bytes += $item.Length
    }
    $queue = [Collections.Generic.Queue[object]]::new()
    $queue.Enqueue([pscustomobject]@{path=$packageRoot;depth=0})
    $seen = 0
    $walked = 0
    while ($queue.Count -gt 0) {
        if (++$walked -gt $MaxFiles * 2) { throw 'Verification traversal limit exceeded.' }
        $directory = $queue.Dequeue()
        $children = @(Get-ChildItem -LiteralPath $directory.path -Force)
        $childIndex = 0
        while ($childIndex -lt $children.Count) {
            $item = $children[$childIndex++]
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Package must not contain links.' }
            if ($item.PSIsContainer) {
                if ($directory.depth -ge $MaxDepth) { throw 'Verification depth limit exceeded.' }
                $queue.Enqueue([pscustomobject]@{path=$item.FullName;depth=$directory.depth+1})
                continue
            }
            $relative = [IO.Path]::GetRelativePath($packageRoot,$item.FullName).Replace('\','/')
            if ($relative -eq 'manifest.json') { continue }
            if (-not $listed.Contains($relative)) { throw "Unlisted file: $relative" }
            $seen++
        }
    }
    if ($seen -ne $listed.Count) { throw 'Package file count differs from manifest.' }
    [pscustomobject]@{version=$manifest.version; sourceCommit=$manifest.sourceCommit; files=$seen; bytes=$bytes; passed=$seen; failed=0}
} catch {
    Write-Error -Message ("{0}`n{1}" -f $_.Exception.Message, $_.ScriptStackTrace) -ErrorAction Continue
    exit 1
}
