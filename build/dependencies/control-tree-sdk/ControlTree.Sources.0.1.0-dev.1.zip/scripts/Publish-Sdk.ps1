#Requires -Version 7
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidatePattern('^[0-9]+\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9.-]+)?$')][string]$Version,
    [ValidateNotNullOrEmpty()][string]$SourceCommit = 'unknown',
    [string]$Root = (Split-Path $PSScriptRoot -Parent),
    [string]$OutputRoot,
    [ValidateRange(1, 1000000)][int]$MaxFiles = 10000,
    [ValidateRange(1, 4096)][int]$MaxDepth = 64
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    $sdkRoot = [IO.Path]::GetFullPath($Root)
    if ([string]::IsNullOrWhiteSpace($OutputRoot)) { $OutputRoot = Join-Path $sdkRoot 'artifacts/sdk' }
    $outputBase = [IO.Path]::GetFullPath($OutputRoot)
    $packageRoot = [IO.Path]::GetFullPath((Join-Path $outputBase $Version))
    if ([IO.Path]::GetDirectoryName($packageRoot) -cne [IO.Path]::TrimEndingDirectorySeparator($outputBase)) { throw 'Version must select one child directory.' }
    if (Test-Path -LiteralPath $packageRoot) { throw "Package already exists: $packageRoot. Select an empty -OutputRoot for a new package." }
    $encoding = [Text.UTF8Encoding]::new($false)
    $entries = [Collections.Generic.List[object]]::new()
    $queue = [Collections.Generic.Queue[object]]::new()
    $roots = @('README.md', 'build.zig', 'build.zig.zon', '.gitattributes', '.gitignore', 'controller', 'abi', 'tools', 'examples', 'scripts', 'docs')
    $rootIndex = 0
    while ($rootIndex -lt $roots.Count) {
        $relative = $roots[$rootIndex++]
        $path = Join-Path $sdkRoot $relative
        if (-not (Test-Path -LiteralPath $path)) { throw "Missing SDK input: $relative" }
        $queue.Enqueue([pscustomobject]@{path=$path; depth=0})
    }
    $visited = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $walkCount = 0
    while ($queue.Count -gt 0) {
        if (++$walkCount -gt $MaxFiles * 2) { throw 'Package traversal limit exceeded.' }
        $entry = $queue.Dequeue()
        $item = Get-Item -LiteralPath $entry.path -Force
        if (-not $visited.Add($item.FullName)) { throw 'Duplicate package input.' }
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'SDK inputs must not contain links or reparse points.' }
        if ($item.PSIsContainer) {
            if ($item.Name -in @('.zig-cache','zig-out','.local','artifacts')) { continue }
            if ($entry.depth -ge $MaxDepth) { throw 'Package depth limit exceeded.' }
            $children = @(Get-ChildItem -LiteralPath $item.FullName -Force)
            $childIndex = 0
            while ($childIndex -lt $children.Count) {
                $queue.Enqueue([pscustomobject]@{path=$children[$childIndex++].FullName; depth=$entry.depth+1})
            }
            continue
        }
        if ($entries.Count -ge $MaxFiles) { throw 'Package file limit exceeded.' }
        $relative = [IO.Path]::GetRelativePath($sdkRoot, $item.FullName).Replace('\', '/')
        if ($relative.StartsWith('../', [StringComparison]::Ordinal)) { throw 'SDK input escaped its root.' }
        $entries.Add([pscustomobject]@{source=$item.FullName; path=$relative})
    }
    [void][IO.Directory]::CreateDirectory($packageRoot)
    $files = [Collections.Generic.List[object]]::new()
    $totalBytes = 0L
    $orderedEntries = @($entries | Sort-Object path -CaseSensitive)
    $fileIndex = 0
    while ($fileIndex -lt $orderedEntries.Count) {
        $entry = $orderedEntries[$fileIndex++]
        $destination = Join-Path $packageRoot $entry.path
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination))
        [IO.File]::Copy($entry.source, $destination, $false)
        $file = Get-Item -LiteralPath $destination
        $files.Add([ordered]@{path=$entry.path; length=$file.Length; sha256=(Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()})
        $totalBytes += $file.Length
    }
    $manifest = [ordered]@{
        version = $Version
        sourceCommit = $SourceCommit
        zigVersion = '0.17.0'
        files = $files.ToArray()
        unfinished = @(
            [ordered]@{requirement='3.5/3'; description='控制器计时器、轮询和定时对账；禁用后没有计时器唤醒。'},
            [ordered]@{requirement='3.5/4'; description='构建期直连优化、标准链路、优化开关、生成清单和等价测试。'},
            [ordered]@{requirement='3.5/5'; description='每个登记表版本公开完整数据表单，以及有权限的外部只读状态访问。'},
            [ordered]@{requirement='3.5/6'; description='启动时检查经过块状态的事实环，失败时列出完整环。'},
            [ordered]@{requirement='dev.2/run-scope'; description='运行作用域：执行计数、块主动关门、计数归零后报告返回。'},
            [ordered]@{requirement='dev.2/host-shells'; description='C# 和 Node 宿主外壳。'}
        )
    }
    [IO.File]::WriteAllText((Join-Path $packageRoot 'manifest.json'), (($manifest | ConvertTo-Json -Depth 8) + "`n").Replace("`r`n", "`n"), $encoding)
    [pscustomobject]@{package=$packageRoot; version=$Version; sourceCommit=$SourceCommit; files=$files.Count; bytes=$totalBytes}
} catch {
    Write-Error -Message ("{0}`n{1}" -f $_.Exception.Message, $_.ScriptStackTrace) -ErrorAction Continue
    exit 1
}
