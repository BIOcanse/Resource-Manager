const std = @import("std");
const control = @import("control_tree");
const abi = @import("control_tree_abi");
const minimal = @import("minimal");
const d = control.declarations;

// An independent consumer fixture with a different topology, registry and UID
// domain. Sharing an Engine type under two ids cannot exercise union dispatch.
const alternate = struct {
    const program: u32 = 101;
    const leaf: u32 = 102;
    const shutdown_item: u32 = 103;
    const condition: u32 = 104;
    const host_blocks = [_]u32{leaf};
    const registry: d.Registry = .{
        .version = "distinct-configurations-fixture",
        .process = "alternate-test",
        .blocks = &.{ .{ .uid = program, .name = null }, .{ .uid = leaf, .name = null } },
        .items = &.{.{
            .uid = shutdown_item,
            .storage = .own,
            .value_type = .bool,
            .per_block = false,
            .trigger = .event,
            .owner_block = null,
            .name = null,
        }},
        .conditions = &.{.{
            .uid = condition,
            .node = program,
            .per_block = false,
            .items = &.{},
            .conditions = &.{},
            .children = &.{},
            .decides = leaf,
            .name = null,
        }},
    };
    fn disabled(_: *control.Input) anyerror!bool {
        return false;
    }
    const topology: control.tree.Tree = .{
        .program = program,
        .blocks = &.{ .{ .uid = program, .parent = null }, .{ .uid = leaf, .parent = program } },
        .uses = &.{},
        .computes = &.{.{ .condition = condition, .function = disabled }},
    };
    const Engine = control.Controller(registry, topology);
};

const Boundary = abi.WithAllocator(.{
    .{ .id = 1, .Controller = minimal.Engine },
    .{ .id = 42, .Controller = alternate.Engine },
}, std.testing.allocator);

const why = abi.ReasonView.fromReason(.{ .kind = 1, .owner = "abi-test", .cause = "distinct-configurations", .plan_version = 1 });
fn noRun(_: ?*anyopaque, _: u32, _: u64) callconv(.c) void {}
fn noComplete(_: ?*anyopaque, _: u64) callconv(.c) void {}
fn noLog(_: ?*anyopaque, _: u32, _: [*]const u8, _: usize) callconv(.c) void {}
fn noChanged(_: ?*anyopaque, _: u64, _: abi.ItemKeyView, _: *const abi.ReasonView) callconv(.c) void {}
const callbacks = abi.HostCallbacks{ .context = null, .start = noRun, .stop = noRun, .complete = noComplete, .log = noLog, .item_changed = noChanged };

fn close(handle: ?*anyopaque) void {
    // Neither fixture requests a run. Shut down before activation, then join
    // controller workers through destroy; the testing allocator checks leaks.
    if (Boundary.control_tree_shutdown(handle, &why, 0) != abi.code(.ok)) @panic("fixture shutdown failed");
    if (Boundary.control_tree_activate(handle) != abi.code(.ok)) @panic("fixture activation failed");
    if (Boundary.control_tree_destroy(handle) != abi.code(.ok)) @panic("fixture destruction failed");
}

test "configuration union dispatches distinct Controller types and isolated UID domains" {
    comptime {
        if (minimal.Engine == alternate.Engine) @compileError("dispatch test needs two distinct Controller types");
    }
    const cases = [_]struct {
        id: u32,
        program: u32,
        leaf: u32,
        foreign_leaf: u32,
        shutdown_item: u32,
        blocks: []const u32,
        registry_version: []const u8,
    }{
        .{
            .id = 1,
            .program = minimal.declarations.BlockUids.Program,
            .leaf = minimal.declarations.BlockUids.Worker,
            .foreign_leaf = alternate.leaf,
            .shutdown_item = minimal.declarations.ItemUids.IsShuttingDown,
            .blocks = &minimal.host_block_uids,
            .registry_version = minimal.registry.version,
        },
        .{
            .id = 42,
            .program = alternate.program,
            .leaf = alternate.leaf,
            .foreign_leaf = minimal.declarations.BlockUids.Worker,
            .shutdown_item = alternate.shutdown_item,
            .blocks = &alternate.host_blocks,
            .registry_version = alternate.registry.version,
        },
    };
    var index: usize = 0;
    while (index < cases.len) : (index += 1) {
        const case = cases[index];
        var needed: usize = 0;
        var uids: [minimal.host_block_uids.len]u32 = undefined;
        try std.testing.expectEqual(abi.code(.ok), Boundary.control_tree_configuration_host_blocks(case.id, &uids, uids.len, &needed));
        try std.testing.expectEqualSlices(u32, case.blocks, uids[0..needed]);

        const o = minimal.options;
        const cfg = abi.Config{
            .struct_size = @sizeOf(abi.Config),
            .configuration = case.id,
            .worker_count = o.worker_count,
            .history_capacity = o.history_capacity,
            .completion_capacity = o.completion_capacity,
            .reader_capacity = o.reader_capacity,
            .reader_bytes = o.reader_bytes,
            .worker_arena_bytes = o.worker_arena_bytes,
            .reason_text_capacity = o.reason_text_capacity,
            .shutdown_item_uid = case.shutdown_item,
            .host_blocks = case.blocks.ptr,
            .host_block_count = @intCast(case.blocks.len),
        };
        var handle: ?*anyopaque = null;
        try std.testing.expectEqual(abi.code(.ok), Boundary.control_tree_create(&cfg, &callbacks, &handle));
        defer close(handle);
        var state: u32 = 99;
        try std.testing.expectEqual(abi.code(.ok), Boundary.control_tree_read_state(handle, case.leaf, &state));
        try std.testing.expectEqual(@backingInt(abi.BlockStateView.stopped), state);
        try std.testing.expectEqual(abi.code(.control_unregistered_block), Boundary.control_tree_read_state(handle, case.foreign_leaf, &state));

        try std.testing.expectEqual(abi.code(.buffer_too_small), Boundary.control_tree_snapshot(handle, null, 0, &needed));
        const bytes = try std.testing.allocator.alloc(u8, needed);
        defer std.testing.allocator.free(bytes);
        try std.testing.expectEqual(abi.code(.ok), Boundary.control_tree_snapshot(handle, bytes.ptr, bytes.len, &needed));
        const parsed = try std.json.parseFromSlice(std.json.Value, std.testing.allocator, bytes, .{});
        defer parsed.deinit();
        try std.testing.expectEqual(@as(i64, case.program), parsed.value.object.get("program").?.integer);
        try std.testing.expectEqualStrings(case.registry_version, parsed.value.object.get("registryVersion").?.string);
        try std.testing.expectEqual(case.blocks.len + 1, parsed.value.object.get("blocks").?.array.items.len);
    }
}
