const std = @import("std");
const control = @import("control_tree");
const abi = @import("control_tree_abi");

const registry: control.declarations.Registry = .{
    .version = "root-only-fixture",
    .process = "root-only-test",
    .blocks = &.{.{ .uid = 201, .name = null }},
    .items = &.{.{
        .uid = 202,
        .storage = .own,
        .value_type = .bool,
        .per_block = false,
        .trigger = .event,
        .owner_block = null,
        .name = null,
    }},
    .conditions = &.{},
};
const topology: control.tree.Tree = .{
    .program = 201,
    .blocks = &.{.{ .uid = 201, .parent = null }},
    .uses = &.{},
    .computes = &.{},
};
const Engine = control.Controller(registry, topology);
const Boundary = abi.WithAllocator(.{.{ .id = 7, .Controller = Engine }}, std.testing.failing_allocator);

test "root-only configuration exports an empty host block list without a buffer or allocation" {
    try std.testing.expectEqual(@as(usize, 0), Engine.runnable_blocks.len);
    var needed: usize = 999;
    try std.testing.expectEqual(abi.code(.ok), Boundary.control_tree_configuration_host_blocks(7, null, 0, &needed));
    try std.testing.expectEqual(@as(usize, 0), needed);
    var sentinel = [_]u32{ 0xaaaa_aaaa, 0xbbbb_bbbb };
    try std.testing.expectEqual(abi.code(.ok), Boundary.control_tree_configuration_host_blocks(7, &sentinel, sentinel.len, &needed));
    try std.testing.expectEqual(@as(usize, 0), needed);
    try std.testing.expectEqualSlices(u32, &.{ 0xaaaa_aaaa, 0xbbbb_bbbb }, &sentinel);
    needed = 999;
    try std.testing.expectEqual(abi.code(.invalid_argument), Boundary.control_tree_configuration_host_blocks(99, null, 0, &needed));
    try std.testing.expectEqual(@as(usize, 0), needed);
}
