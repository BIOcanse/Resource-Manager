const std = @import("std");
const generated = @import("minimal").declarations;

fn checkTable(table: anytype) !void {
    const has_names = generated.development.len != 0;
    var index: usize = 0;
    while (index < table.len) : (index += 1) {
        const declaration = table[index];
        try std.testing.expect(declaration.uid != 0);
        if (!has_names) {
            try std.testing.expect(declaration.name == null);
            continue;
        }
        const name = declaration.name orelse return error.MissingGeneratedName;
        try std.testing.expect(std.mem.trim(u8, name, " \t\r\n").len > 0);
        var matches: usize = 0;
        var entry_index: usize = 0;
        while (entry_index < generated.development.len) : (entry_index += 1) {
            const entry = generated.development[entry_index];
            if (entry.uid != declaration.uid) continue;
            matches += 1;
            try std.testing.expectEqualStrings(name, entry.name);
            try std.testing.expect(std.mem.trim(u8, entry.comment, " \t\r\n").len > 0);
        }
        try std.testing.expectEqual(@as(usize, 1), matches);
    }
}

test "generated registry names and development metadata are retained or stripped together" {
    const registry = generated.registry;
    try checkTable(registry.blocks);
    try checkTable(registry.items);
    try checkTable(registry.conditions);
    if (generated.development.len == 0) return;

    try std.testing.expectEqual(registry.blocks.len + registry.items.len + registry.conditions.len, generated.development.len);
    var index: usize = 0;
    while (index < generated.development.len) : (index += 1) {
        const entry = generated.development[index];
        try std.testing.expect(entry.uid != 0);
        try std.testing.expect(std.mem.trim(u8, entry.name, " \t\r\n").len > 0);
        try std.testing.expect(std.mem.trim(u8, entry.comment, " \t\r\n").len > 0);
        var earlier: usize = 0;
        while (earlier < index) : (earlier += 1) {
            try std.testing.expect(generated.development[earlier].uid != entry.uid);
        }
    }
}
