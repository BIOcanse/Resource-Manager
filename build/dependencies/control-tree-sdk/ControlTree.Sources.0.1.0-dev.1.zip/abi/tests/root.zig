test {
    _ = @import("layout.zig");
    _ = @import("error_mapping.zig");
    _ = @import("boundary.zig");
    _ = @import("generated_names.zig");
    _ = @import("distinct_configurations.zig");
    _ = @import("root_only.zig");
    _ = @import("minimal_scenarios");
}
