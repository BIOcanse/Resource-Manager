const std = @import("std");
const abi = @import("control_tree_abi");

test "every reachable controller error has an explicit result code" {
    try std.testing.expectEqual(abi.code(.out_of_memory), abi.codeFor(error.OutOfMemory));
    try std.testing.expectEqual(abi.code(.invalid_argument), abi.codeFor(error.InvalidArgument));
    try std.testing.expectEqual(abi.code(.abi_mismatch), abi.codeFor(error.AbiMismatch));
    try std.testing.expectEqual(abi.code(.unavailable), abi.codeFor(error.ThreadQuotaExceeded));
    try std.testing.expectEqual(abi.code(.unavailable), abi.codeFor(error.SystemResources));
    try std.testing.expectEqual(abi.code(.unavailable), abi.codeFor(error.LockedMemoryLimitExceeded));
    try std.testing.expectEqual(abi.code(.unavailable), abi.codeFor(error.Unexpected));
    try std.testing.expectEqual(abi.code(.control_invalid_configuration), abi.codeFor(error.InvalidConfiguration));
    try std.testing.expectEqual(abi.code(.control_host_blocks_mismatch), abi.codeFor(error.HostBlocksMismatch));
    try std.testing.expectEqual(abi.code(.control_undeclared_item), abi.codeFor(error.UnregisteredItem));
    try std.testing.expectEqual(abi.code(.control_unregistered_block), abi.codeFor(error.UnregisteredBlock));
    try std.testing.expectEqual(abi.code(.control_storage_mismatch), abi.codeFor(error.StorageMismatch));
    try std.testing.expectEqual(abi.code(.control_duplicate_claim), abi.codeFor(error.AlreadyClaimed));
    try std.testing.expectEqual(abi.code(.control_invalid_claim), abi.codeFor(error.InvalidClaim));
    try std.testing.expectEqual(abi.code(.control_type_mismatch), abi.codeFor(error.TypeMismatch));
    try std.testing.expectEqual(abi.code(.control_not_active), abi.codeFor(error.NotActive));
    try std.testing.expectEqual(abi.code(.control_completion_full), abi.codeFor(error.CompletionFull));
    try std.testing.expectEqual(abi.code(.invalid_argument), abi.codeFor(error.InvalidReason));
    try std.testing.expectEqual(abi.code(.control_reason_too_long), abi.codeFor(error.ReasonTooLong));
    try std.testing.expectEqual(abi.code(.control_invalid_holder), abi.codeFor(error.InvalidHolder));
    try std.testing.expectEqual(abi.code(.control_duplicate_reader), abi.codeFor(error.DuplicateHolder));
    try std.testing.expectEqual(abi.code(.control_reader_full), abi.codeFor(error.ReaderFull));
    try std.testing.expectEqual(abi.code(.control_not_shutting_down), abi.codeFor(error.NotShuttingDown));
    try std.testing.expectEqual(abi.code(.control_runs_active), abi.codeFor(error.RunsActive));
}
