const std = @import("std");
const control = @import("control_tree");
const abi = @import("control_tree_abi");
const minimal = @import("minimal");
const I = minimal.declarations.ItemUids;
const Boundary = abi.WithAllocator(.{
    .{ .id = 1, .Controller = minimal.Engine },
    .{ .id = 42, .Controller = minimal.Engine },
}, std.testing.allocator);
const eq = std.testing.expectEqual;
const why = abi.ReasonView{ .kind = 1, .owner = "abi-test", .owner_length = 8, .cause = "boundary", .cause_length = 8, .plan_version = 1 };

fn config() abi.Config {
    const o = minimal.options;
    return .{
        .struct_size = @sizeOf(abi.Config),
        .configuration = o.configuration,
        .worker_count = o.worker_count,
        .history_capacity = o.history_capacity,
        .completion_capacity = o.completion_capacity,
        .reader_capacity = o.reader_capacity,
        .reader_bytes = o.reader_bytes,
        .worker_arena_bytes = o.worker_arena_bytes,
        .reason_text_capacity = o.reason_text_capacity,
        .shutdown_item_uid = I.IsShuttingDown,
        .host_blocks = &minimal.host_block_uids,
        .host_block_count = minimal.host_block_uids.len,
    };
}
fn noStart(_: ?*anyopaque, _: u32, _: u64) callconv(.c) void {}
fn noStop(_: ?*anyopaque, _: u32, _: u64) callconv(.c) void {}
fn noComplete(_: ?*anyopaque, _: u64) callconv(.c) void {}
fn noLog(_: ?*anyopaque, _: u32, _: [*]const u8, _: usize) callconv(.c) void {}
fn noChanged(_: ?*anyopaque, _: u64, _: abi.ItemKeyView, _: *const abi.ReasonView) callconv(.c) void {}
fn callbacks() abi.HostCallbacks {
    return .{ .context = null, .start = noStart, .stop = noStop, .complete = noComplete, .log = noLog, .item_changed = noChanged };
}
fn close(handle: ?*anyopaque) void {
    _ = Boundary.control_tree_shutdown(handle, &why, 0);
    _ = Boundary.control_tree_activate(handle);
    if (Boundary.control_tree_destroy(handle) != abi.code(.ok)) @panic("ABI test cleanup failed");
}

test "unknown configuration is rejected before allocation while valid configuration reports out of memory" {
    const FailingBoundary = abi.WithAllocator(.{
        .{ .id = 1, .Controller = minimal.Engine },
    }, std.testing.failing_allocator);
    var cfg = config();
    const cb = callbacks();
    var handle: ?*anyopaque = null;
    cfg.configuration = 999;
    try eq(abi.code(.invalid_argument), FailingBoundary.control_tree_create(&cfg, &cb, &handle));
    try std.testing.expect(handle == null);
    cfg.configuration = 1;
    try eq(abi.code(.out_of_memory), FailingBoundary.control_tree_create(&cfg, &cb, &handle));
    try std.testing.expect(handle == null);
}

test "configuration selection and short host block buffers preserve caller memory" {
    const ids = [_]u32{ 1, 42 };
    var index: usize = 0;
    while (index < ids.len) : (index += 1) {
        var needed: usize = 999;
        const id = ids[index];
        try eq(abi.code(.buffer_too_small), Boundary.control_tree_configuration_host_blocks(id, null, 0, &needed));
        try eq(minimal.host_block_uids.len, needed);
        var out: [3]u32 = @splat(0xaaaa_aaaa);
        try eq(abi.code(.buffer_too_small), Boundary.control_tree_configuration_host_blocks(id, &out, 1, &needed));
        try std.testing.expectEqualSlices(u32, &.{ 0xaaaa_aaaa, 0xaaaa_aaaa, 0xaaaa_aaaa }, &out);
        try eq(abi.code(.invalid_argument), Boundary.control_tree_configuration_host_blocks(id, null, 2, &needed));
        try eq(abi.code(.ok), Boundary.control_tree_configuration_host_blocks(id, &out, out.len, &needed));
        try std.testing.expectEqualSlices(u32, &minimal.host_block_uids, out[0..needed]);
        try eq(@as(u32, 0xaaaa_aaaa), out[2]);
        var cfg = config();
        cfg.configuration = id;
        const cb = callbacks();
        var handle: ?*anyopaque = null;
        try eq(abi.code(.ok), Boundary.control_tree_create(&cfg, &cb, &handle));
        close(handle);
    }
    var needed: usize = 999;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_configuration_host_blocks(99, null, 0, &needed));
    try eq(@as(usize, 0), needed);
    try eq(abi.code(.invalid_argument), Boundary.control_tree_configuration_host_blocks(1, null, 0, null));
}

test "create rejects incomplete callbacks ABI mismatch host mismatch and invalid settings without leaks" {
    var cfg = config();
    var cb = callbacks();
    var handle: ?*anyopaque = null;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(null, &cb, &handle));
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, null, &handle));
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, null));
    cfg.struct_size -= 1;
    try eq(abi.code(.abi_mismatch), Boundary.control_tree_create(&cfg, &cb, &handle));
    try std.testing.expect(handle == null);
    cfg = config();
    cfg.configuration = 999;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, &handle));
    cfg = config();
    cfg.host_block_count = 1;
    try eq(abi.code(.control_host_blocks_mismatch), Boundary.control_tree_create(&cfg, &cb, &handle));
    cfg = config();
    cfg.host_blocks = null;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, &handle));
    cfg = config();
    cfg.worker_count = 0;
    try eq(abi.code(.control_invalid_configuration), Boundary.control_tree_create(&cfg, &cb, &handle));
    cfg = config();
    cb.start = null;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, &handle));
    cb = callbacks();
    cb.stop = null;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, &handle));
    cb = callbacks();
    cb.complete = null;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, &handle));
    cb = callbacks();
    cb.log = null;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, &handle));
    cb = callbacks();
    cb.item_changed = null;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_create(&cfg, &cb, &handle));
    try std.testing.expect(handle == null);
}

test "claims reads readers snapshots and shutdown retain boundary semantics" {
    const cfg = config();
    const cb = callbacks();
    var handle: ?*anyopaque = null;
    try eq(abi.code(.ok), Boundary.control_tree_create(&cfg, &cb, &handle));
    defer close(handle);
    try eq(abi.code(.control_not_shutting_down), Boundary.control_tree_destroy(handle));
    const key = abi.ItemKeyView{ .item = I.HostStartPermitted, .block = 0 };
    const unknown = abi.ItemKeyView{ .item = 999, .block = 0 };
    var claim: ?*anyopaque = null;
    var duplicate: ?*anyopaque = null;
    try eq(abi.code(.control_storage_mismatch), Boundary.control_tree_claim_write(handle, &key, &claim));
    try eq(abi.code(.control_undeclared_item), Boundary.control_tree_claim_cell(handle, &unknown, &claim));
    try eq(abi.code(.ok), Boundary.control_tree_claim_cell(handle, &key, &claim));
    try eq(abi.code(.control_duplicate_claim), Boundary.control_tree_claim_cell(handle, &key, &duplicate));
    try std.testing.expect(duplicate == null);
    try eq(abi.code(.invalid_argument), Boundary.control_tree_publish(handle, claim, 99, &why, 0));
    try eq(abi.code(.invalid_argument), Boundary.control_tree_publish_presence(handle, claim, 99, &why, 0));
    try eq(abi.code(.control_type_mismatch), Boundary.control_tree_publish_presence(handle, claim, 0, &why, 0));
    try eq(abi.code(.invalid_argument), Boundary.control_tree_publish(handle, null, 3, &why, 0));
    try eq(abi.code(.ok), Boundary.control_tree_publish(handle, claim, 3, &why, 0));
    try eq(abi.code(.control_not_active), Boundary.control_tree_publish(handle, claim, 3, &why, 1));
    var invalid_reason = why;
    invalid_reason.owner_length = 0;
    try eq(abi.code(.invalid_argument), Boundary.control_tree_publish(handle, claim, 3, &invalid_reason, 0));
    const long_text: [minimal.options.reason_text_capacity + 1]u8 = @splat('x');
    var long_reason = why;
    long_reason.owner = &long_text;
    long_reason.owner_length = long_text.len;
    try eq(abi.code(.control_reason_too_long), Boundary.control_tree_publish(handle, claim, 3, &long_reason, 0));
    var value: u32 = 99;
    try eq(abi.code(.ok), Boundary.control_tree_read(handle, &key, &value));
    try eq(@as(u32, 3), value);
    try eq(abi.code(.control_type_mismatch), Boundary.control_tree_read_presence(handle, &key, &value));
    try eq(abi.code(.control_unregistered_block), Boundary.control_tree_read_state(handle, 999, &value));
    var id: u64 = 0;
    var other: u64 = 99;
    try eq(abi.code(.ok), Boundary.control_tree_register_reader(handle, &key, "reader", 6, &id));
    try eq(abi.code(.control_duplicate_reader), Boundary.control_tree_register_reader(handle, &key, "reader", 6, &other));
    try eq(@as(u64, 0), other);
    try eq(abi.code(.control_invalid_holder), Boundary.control_tree_register_reader(handle, &key, null, 0, &other));
    try eq(abi.code(.ok), Boundary.control_tree_unregister_reader(handle, id));
    try eq(abi.code(.ok), Boundary.control_tree_unregister_reader(handle, id));
    var required: usize = 0;
    try eq(abi.code(.buffer_too_small), Boundary.control_tree_snapshot(handle, null, 0, &required));
    try std.testing.expect(required > 0);
    const bytes = try std.testing.allocator.alloc(u8, required);
    defer std.testing.allocator.free(bytes);
    try eq(abi.code(.ok), Boundary.control_tree_snapshot(handle, bytes.ptr, bytes.len, &required));
    const parsed = try std.json.parseFromSlice(std.json.Value, std.testing.allocator, bytes, .{});
    defer parsed.deinit();
    try std.testing.expectEqualStrings(minimal.registry.version, parsed.value.object.get("registryVersion").?.string);
    try eq(abi.code(.invalid_argument), Boundary.control_tree_snapshot(handle, null, 1, &required));
    try eq(abi.code(.invalid_argument), Boundary.control_tree_snapshot(handle, null, 0, null));
    try eq(abi.code(.ok), Boundary.control_tree_unbind(handle, claim, &why, 0));
    try eq(abi.code(.ok), Boundary.control_tree_read(handle, &key, &value));
    try eq(@as(u32, 1), value);
    try eq(abi.code(.ok), Boundary.control_tree_bind(handle, claim, &why, 0));
    try eq(abi.code(.ok), Boundary.control_tree_read(handle, &key, &value));
    try eq(@as(u32, 3), value);
}

const FunctionContext = struct { handle: ?*anyopaque, value: bool = false, calls: usize = 0, reentry: i32 = -1 };
fn readFunction(raw: ?*anyopaque, output: *abi.FunctionRead) callconv(.c) void {
    const context: *FunctionContext = @ptrCast(@alignCast(raw.?));
    var state: u32 = 99;
    context.reentry = Boundary.control_tree_read_state(context.handle, 2, &state);
    context.calls += 1;
    output.* = .{ .kind = 3, .value = @intFromBool(context.value) };
}

test "read functions reenter outside controller locks and unbind suppresses owner access" {
    const cfg = config();
    const cb = callbacks();
    var handle: ?*anyopaque = null;
    try eq(abi.code(.ok), Boundary.control_tree_create(&cfg, &cb, &handle));
    defer close(handle);
    var context = FunctionContext{ .handle = handle };
    const function = abi.ReadFunction{ .context = &context, .read = readFunction };
    const key = abi.ItemKeyView{ .item = I.HostStartPermitted, .block = 0 };
    var claim: ?*anyopaque = null;
    try eq(abi.code(.ok), Boundary.control_tree_claim_read_function(handle, &key, &function, &claim));
    var value: u32 = 99;
    try eq(abi.code(.ok), Boundary.control_tree_read(handle, &key, &value));
    try eq(@as(u32, 3), value);
    context.value = true;
    try eq(abi.code(.ok), Boundary.control_tree_notify_changed(handle, claim, &why, 0));
    try eq(abi.code(.ok), Boundary.control_tree_read(handle, &key, &value));
    try eq(@as(u32, 4), value);
    try eq(abi.code(.ok), context.reentry);
    try eq(abi.code(.ok), Boundary.control_tree_unbind(handle, claim, &why, 0));
    const calls = context.calls;
    try eq(abi.code(.ok), Boundary.control_tree_read(handle, &key, &value));
    try eq(@as(u32, 1), value);
    try eq(calls, context.calls);
    try eq(abi.code(.ok), Boundary.control_tree_bind(handle, claim, &why, 0));
    try eq(abi.code(.ok), Boundary.control_tree_read(handle, &key, &value));
    try eq(@as(u32, 4), value);
    // Keep the unactivated controller's decision rules from starting any runs.
    context.value = false;
}
