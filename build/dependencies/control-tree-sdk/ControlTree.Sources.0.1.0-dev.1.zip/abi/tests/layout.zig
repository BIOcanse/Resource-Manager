//! The C source is translated by the build. All extern structs and every field
//! are compared on the selected target, without assuming a 64-bit layout.
const std = @import("std");
const abi = @import("control_tree_abi");
const c = @import("control_tree_header");

fn sameLayout(comptime Zig: type, comptime C: type) !void {
    try std.testing.expectEqual(@sizeOf(Zig), @sizeOf(C));
    try std.testing.expectEqual(@alignOf(Zig), @alignOf(C));
    const fields = @typeInfo(Zig).@"struct";
    try std.testing.expectEqual(fields.field_names.len, @typeInfo(C).@"struct".field_names.len);
    inline for (fields.field_names) |name| {
        try std.testing.expectEqual(@offsetOf(Zig, name), @offsetOf(C, name));
        try std.testing.expectEqual(@sizeOf(@FieldType(Zig, name)), @sizeOf(@FieldType(C, name)));
    }
}

test "translated C structs match every Zig extern size alignment and field offset" {
    try sameLayout(abi.Config, c.control_tree_config);
    try sameLayout(abi.HostCallbacks, c.control_tree_host_callbacks);
    try sameLayout(abi.ItemKeyView, c.control_tree_item_key);
    try sameLayout(abi.ReasonView, c.control_tree_reason);
    try sameLayout(abi.FunctionRead, c.control_tree_function_read);
    try sameLayout(abi.ReadFunction, c.control_tree_read_function);
}

test "C enum and ABI constants match Zig" {
    @setEvalBranchQuota(10_000);
    try std.testing.expectEqual(abi.abi_version, c.CONTROL_TREE_ABI_VERSION);
    try std.testing.expectEqual(@backingInt(abi.ReadView.not_published), c.CONTROL_TREE_READ_NOT_PUBLISHED);
    try std.testing.expectEqual(@backingInt(abi.ReadView.owner_stopped), c.CONTROL_TREE_READ_OWNER_STOPPED);
    try std.testing.expectEqual(@backingInt(abi.ReadView.read_failed), c.CONTROL_TREE_READ_FAILED);
    try std.testing.expectEqual(@backingInt(abi.ReadView.false_value), c.CONTROL_TREE_READ_FALSE);
    try std.testing.expectEqual(@backingInt(abi.ReadView.true_value), c.CONTROL_TREE_READ_TRUE);
    try std.testing.expectEqual(@backingInt(abi.PresenceView.present), c.CONTROL_TREE_PRESENT);
    try std.testing.expectEqual(@backingInt(abi.PresenceView.not_published), c.CONTROL_TREE_PRESENCE_NOT_PUBLISHED);
    try std.testing.expectEqual(@backingInt(abi.PresenceView.owner_stopped), c.CONTROL_TREE_PRESENCE_OWNER_STOPPED);
    try std.testing.expectEqual(@backingInt(abi.PresenceView.read_failed), c.CONTROL_TREE_PRESENCE_READ_FAILED);
    try std.testing.expectEqual(@backingInt(abi.BlockStateView.stopped), c.CONTROL_TREE_STOPPED);
    try std.testing.expectEqual(@backingInt(abi.BlockStateView.starting), c.CONTROL_TREE_STARTING);
    try std.testing.expectEqual(@backingInt(abi.BlockStateView.running), c.CONTROL_TREE_RUNNING);
    try std.testing.expectEqual(@backingInt(abi.BlockStateView.stopping), c.CONTROL_TREE_STOPPING);
    inline for (@typeInfo(abi.ResultCode).@"enum".field_names) |name| {
        const suffix = if (comptime std.mem.startsWith(u8, name, "control_")) name[8..] else name;
        const c_name = comptime blk: {
            const prefix = "CONTROL_TREE_";
            var text: [prefix.len + suffix.len:0]u8 = undefined;
            @memcpy(text[0..prefix.len], prefix);
            var index: usize = 0;
            while (index < suffix.len) : (index += 1) text[prefix.len + index] = std.ascii.toUpper(suffix[index]);
            text[text.len] = 0;
            break :blk text;
        };
        try std.testing.expectEqual(@backingInt(@field(abi.ResultCode, name)), @field(c, &c_name));
    }
}
