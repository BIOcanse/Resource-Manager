//! Called from the SDK root build; all paths are relative to that package root.
const std = @import("std");

pub const Modules = struct {
    control: *std.Build.Module,
    abi: *std.Build.Module,
    state_items: *std.Build.Module,
    minimal: *std.Build.Module,
};

pub fn makeModules(b: *std.Build, target: std.Build.ResolvedTarget, control: *std.Build.Module, state_names: bool) Modules {
    const options = b.addOptions();
    options.addOption(bool, "state_names", state_names);
    const registry = b.createModule(.{
        .root_source_file = b.path("examples/minimal/generated/state_items.zig"),
        .target = target,
        .optimize = .safe,
    });
    registry.addImport("control_tree", control);
    registry.addOptions("build_options", options);
    const abi = b.addModule("control_tree_abi", .{
        .root_source_file = b.path("abi/src/export.zig"),
        .target = target,
        .optimize = .safe,
    });
    abi.addImport("control_tree", control);
    const minimal = b.createModule(.{
        .root_source_file = b.path("examples/minimal/src/tree.zig"),
        .target = target,
        .optimize = .safe,
    });
    minimal.addImport("control_tree", control);
    minimal.addImport("minimal_state_items", registry);
    const parameters = b.addOptions();
    parameters.addOption(u32, "worker_count", b.option(u32, "example-workers", "Minimal consumer controller workers") orelse 2);
    parameters.addOption(u32, "history_capacity", b.option(u32, "example-history-capacity", "Minimal consumer retained history rows per node") orelse 64);
    parameters.addOption(u32, "completion_capacity", b.option(u32, "example-completion-capacity", "Minimal consumer outstanding completion tokens") orelse 16);
    parameters.addOption(u32, "reader_capacity", b.option(u32, "example-reader-capacity", "Minimal consumer runtime reader slots") orelse 8);
    parameters.addOption(u32, "reader_bytes", b.option(u32, "example-reader-bytes", "Minimal consumer reader storage bytes") orelse 2048);
    parameters.addOption(u32, "worker_arena_bytes", b.option(u32, "example-worker-arena-bytes", "Minimal consumer scratch bytes per worker") orelse 65536);
    parameters.addOption(u32, "reason_text_capacity", b.option(u32, "example-reason-text-capacity", "Minimal consumer retained owner and cause bytes per reason") orelse 256);
    minimal.addOptions("example_options", parameters);
    return .{ .control = control, .abi = abi, .state_items = registry, .minimal = minimal };
}

pub const Example = struct {
    library: *std.Build.Step.Compile,
    export_tree: *std.Build.Step.Compile,
};

pub fn addExample(b: *std.Build, target: std.Build.ResolvedTarget, modules: Modules) Example {
    const root = b.createModule(.{
        .root_source_file = b.path("examples/minimal/src/library.zig"),
        .target = target,
        .optimize = .safe,
    });
    root.addImport("control_tree_abi", modules.abi);
    root.addImport("minimal", modules.minimal);
    const library = b.addLibrary(.{ .name = "control_tree_minimal", .linkage = .dynamic, .root_module = root });
    const source = b.createModule(.{
        .root_source_file = b.path("examples/minimal/src/export_tree.zig"),
        .target = target,
        .optimize = .safe,
    });
    source.addImport("control_tree", modules.control);
    source.addImport("minimal", modules.minimal);
    const export_root = b.createModule(.{
        .root_source_file = b.path("controller/src/export_tree_main.zig"),
        .target = target,
        .optimize = .safe,
    });
    export_root.addImport("control_tree", modules.control);
    export_root.addImport("process_tree", source);
    const export_tree = b.addExecutable(.{ .name = "control_tree_minimal_export", .root_module = export_root });
    return .{ .library = library, .export_tree = export_tree };
}

/// Includes target-native translate-c layout checks and a real DLL load. Reuse
/// addExample's result so install and tests build the very same dynamic library.
pub fn addTests(b: *std.Build, target: std.Build.ResolvedTarget, modules: Modules, example: Example) *std.Build.Step {
    const translated = b.addTranslateC(.{
        .root_source_file = b.path("abi/include/control_tree.h"),
        .target = target,
        .optimize = .safe,
        .link_libc = false,
    });
    const runtime = b.addOptions();
    runtime.addOptionPath("library_path", example.library.getEmittedBin());
    const scenarios = b.createModule(.{
        .root_source_file = b.path("examples/minimal/tests/scenarios.zig"),
        .target = target,
        .optimize = .safe,
    });
    scenarios.addImport("control_tree", modules.control);
    scenarios.addImport("control_tree_abi", modules.abi);
    scenarios.addImport("minimal", modules.minimal);
    scenarios.addOptions("runtime_options", runtime);
    const root = b.createModule(.{
        .root_source_file = b.path("abi/tests/root.zig"),
        .target = target,
        .optimize = .safe,
    });
    root.addImport("control_tree", modules.control);
    root.addImport("control_tree_abi", modules.abi);
    root.addImport("minimal", modules.minimal);
    root.addImport("control_tree_header", translated.createModule());
    root.addImport("minimal_scenarios", scenarios);
    const tests = b.addTest(.{ .name = "control_tree_abi_tests", .root_module = root });
    const run = b.addRunArtifact(tests);
    const step = b.step("test-abi", "Check C layout, boundary errors and direct/DLL scenario equivalence");
    step.dependOn(&run.step);
    return step;
}
