# C boundary

The consumer builds the controller, declarations and conditions into its own
dynamic library. `include/control_tree.h` is fixed across consumers and contains
no business UIDs or configuration enum. ABI version: `0x00010000`.

```zig
const Boundary = @import("control_tree_abi").Exporter(.{
    .{ .id = 1, .Controller = MyController },
    .{ .id = 7, .Controller = OtherController },
});
comptime { Boundary.exportSymbols(); }
```

Each `Controller` is the existing `control_tree.Controller(registry, topology)`.
The exporter generates a tagged union and exports one fixed set of
`control_tree_` symbols. Instantiate and export it once per library.
The exporter reads the exact non-root UID list from `Controller.runnable_blocks`,
a read-only compile-time view of its topology. The C `Config.host_blocks` field
separately declares the host's actual runnable registrations, which the controller
validates during create.

Zig tests may use `WithAllocator(entries, std.testing.allocator)` to check session,
worker and controller allocations for leaks. The default exporter uses the page
allocator, as the original C boundary did.

All callbacks are required. They only queue work and return immediately. The host
owns executors, stop tokens and run lifetimes. It reports a return only after that
run's work and cleanup have ended. Old run reports are ignored. Strings are
borrowed during a call; reasons retained by the controller are copied. A read
function's context lives until destruction, including while unbound. Destroy
requires shutdown and all runs returned. Completion token zero means no callback.

No demand API, timer implementation, polling callback or host runtime scope is
added in this version. The five event callbacks are start, stop, complete, log and
item_changed. Read functions are separate synchronous current-value accessors.

`build-support.zig` wires target-native `translate-c` layout checks, boundary
tests, and direct Zig versus dynamically loaded minimal-library scenarios into
`test-abi`. The current controller synchronization and the dynamic loader test
require Windows. See the minimal example for the consumer-owned declarations.
