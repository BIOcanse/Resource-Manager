const std = @import("std");
const control = @import("control_tree");
pub const ResultCode = @import("result_codes.zig").ResultCode;

pub const abi_version: u32 = 0x0001_0000;

/// Fixed-width host configuration. The selected configuration has one fixed tree;
/// `host_blocks` must exactly match the host's runnable block registrations.
pub const Config = extern struct {
    struct_size: u32,
    configuration: u32,
    worker_count: u32,
    history_capacity: u32,
    completion_capacity: u32,
    reader_capacity: u32,
    reader_bytes: u32,
    worker_arena_bytes: u32,
    reason_text_capacity: u32,
    shutdown_item_uid: u32,
    host_blocks: ?[*]const u32,
    host_block_count: u32,
};

/// Log and reason lengths use native `usize` to
/// match `control_tree.types.Host` and `control_tree.types.ReasonView`.
pub const HostCallbacks = extern struct {
    context: ?*anyopaque,
    start: ?*const fn (?*anyopaque, u32, u64) callconv(.c) void,
    stop: ?*const fn (?*anyopaque, u32, u64) callconv(.c) void,
    complete: ?*const fn (?*anyopaque, u64) callconv(.c) void,
    log: ?*const fn (?*anyopaque, u32, [*]const u8, usize) callconv(.c) void,
    item_changed: ?*const fn (?*anyopaque, u64, control.types.ItemKeyView, *const control.types.ReasonView) callconv(.c) void,
};

pub const ItemKeyView = control.types.ItemKeyView;
pub const ReasonView = control.types.ReasonView;
pub const ReadFunction = control.types.ReadFunction;
pub const FunctionRead = control.types.ReadView;

/// Values cross the ABI as `u32`; invalid values are rejected before they
/// reach the controller's tagged unions.
pub const ReadView = enum(u32) {
    not_published = 0,
    owner_stopped = 1,
    read_failed = 2,
    false_value = 3,
    true_value = 4,
};

pub const PresenceView = enum(u32) {
    present = 0,
    not_published = 1,
    owner_stopped = 2,
    read_failed = 3,
};

pub const BlockStateView = enum(u32) {
    stopped = 0,
    starting = 1,
    running = 2,
    stopping = 3,
};

/// One entry supplies a positive configuration id and its concrete Controller type.
/// Its non-root block UIDs come from Controller.runnable_blocks metadata.
/// Instantiate once per library, then call exportSymbols() from its root comptime.
pub fn Exporter(comptime configurations: anytype) type {
    return WithAllocator(configurations, std.heap.page_allocator);
}

/// Allocator injection is for Zig hosts and leak/failure tests; it changes no C ABI.
pub fn WithAllocator(comptime configurations: anytype, comptime allocator: std.mem.Allocator) type {
    if (configurations.len == 0) @compileError("at least one control tree configuration is required");
    var names: [configurations.len][:0]const u8 = undefined;
    var ids: [configurations.len]u32 = undefined;
    var pointers: [configurations.len]type = undefined;
    const attrs: [configurations.len]std.builtin.Type.Union.FieldAttributes = @splat(.{});
    var index: usize = 0;
    while (index < configurations.len) : (index += 1) {
        const entry = configurations[index];
        if (entry.id == 0) @compileError("configuration id must be positive");
        var earlier: usize = 0;
        while (earlier < index) : (earlier += 1) {
            if (configurations[earlier].id == entry.id) @compileError("configuration ids must be unique");
        }
        names[index] = std.fmt.comptimePrint("configuration_{d}", .{entry.id});
        ids[index] = entry.id;
        pointers[index] = *entry.Controller;
    }
    const field_names = names;
    const Tag = @Enum(u32, .exhaustive, &field_names, &ids);
    const ControllerUnion = @Union(.auto, Tag, &field_names, &pointers, &attrs);
    return struct {
        const Session = struct { controller: ControllerUnion };
        fn castSession(handle: ?*anyopaque) ?*Session {
            return @ptrCast(@alignCast(handle orelse return null));
        }
        fn configurationBlocks(id: u32) ?[]const u32 {
            inline for (configurations) |entry| {
                if (id == entry.id) return entry.Controller.runnable_blocks;
            }
            return null;
        }
        pub fn exportSymbols() void {
            const Self = @This();
            inline for (symbol_names) |name| @export(&@field(Self, name), .{ .name = name });
        }
        pub fn control_tree_abi_version() callconv(.c) u32 {
            return abi_version;
        }

        /// Copies the configuration's exact non-root host UIDs. Capacity and needed are UID
        /// counts, not byte lengths. A short buffer is left untouched.
        pub fn control_tree_configuration_host_blocks(
            configuration: u32,
            buffer: ?[*]u32,
            capacity: usize,
            needed_pointer: ?*usize,
        ) callconv(.c) i32 {
            const needed = needed_pointer orelse return code(.invalid_argument);
            needed.* = 0;
            const blocks = configurationBlocks(configuration) orelse return code(.invalid_argument);
            needed.* = blocks.len;
            if (capacity < blocks.len) return code(.buffer_too_small);
            if (blocks.len == 0) return code(.ok);
            const output = buffer orelse return code(.invalid_argument);
            @memcpy(output[0..blocks.len], blocks);
            return code(.ok);
        }

        pub fn control_tree_create(
            config_pointer: ?*const Config,
            callbacks_pointer: ?*const HostCallbacks,
            output_handle: ?*?*anyopaque,
        ) callconv(.c) i32 {
            const output = output_handle orelse return code(.invalid_argument);
            output.* = null;

            const config_view = config_pointer orelse return code(.invalid_argument);
            if (config_view.struct_size != @sizeOf(Config)) return code(.abi_mismatch);
            const callbacks_view = callbacks_pointer orelse return code(.invalid_argument);
            const callbacks = hostFrom(callbacks_view) orelse return code(.invalid_argument);
            if (configurationBlocks(config_view.configuration) == null) return code(.invalid_argument);
            const config = configFrom(config_view) catch |err| return codeFor(err);

            const session = allocator.create(Session) catch return code(.out_of_memory);
            inline for (configurations, 0..) |entry, entry_index| {
                if (config_view.configuration == entry.id) {
                    const engine = entry.Controller.create(allocator, config, callbacks) catch |err| {
                        allocator.destroy(session);
                        return codeFor(err);
                    };
                    session.* = .{ .controller = @unionInit(ControllerUnion, field_names[entry_index], engine) };
                    output.* = @ptrCast(session);
                    return code(.ok);
                }
            }
            allocator.destroy(session);
            return code(.invalid_argument);
        }

        pub fn control_tree_activate(handle: ?*anyopaque) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            switch (session.controller) {
                inline else => |controller| controller.activate(),
            }
            return code(.ok);
        }

        pub fn control_tree_destroy(handle: ?*anyopaque) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            switch (session.controller) {
                inline else => |controller| controller.destroy() catch |err| return codeFor(err),
            }
            allocator.destroy(session);
            return code(.ok);
        }

        pub fn control_tree_claim_write(
            handle: ?*anyopaque,
            key_pointer: ?*const ItemKeyView,
            output_claim: ?*?*anyopaque,
        ) callconv(.c) i32 {
            const output = output_claim orelse return code(.invalid_argument);
            output.* = null;
            const session = castSession(handle) orelse return code(.invalid_argument);
            const key = key_pointer orelse return code(.invalid_argument);
            const claim = switch (session.controller) {
                inline else => |controller| controller.claimWrite(key.toKey()) catch |err| return codeFor(err),
            };
            output.* = @ptrCast(claim);
            return code(.ok);
        }

        pub fn control_tree_claim_cell(
            handle: ?*anyopaque,
            key_pointer: ?*const ItemKeyView,
            output_claim: ?*?*anyopaque,
        ) callconv(.c) i32 {
            const output = output_claim orelse return code(.invalid_argument);
            output.* = null;
            const session = castSession(handle) orelse return code(.invalid_argument);
            const key = key_pointer orelse return code(.invalid_argument);
            const claim = switch (session.controller) {
                inline else => |controller| controller.claimCell(key.toKey()) catch |err| return codeFor(err),
            };
            output.* = @ptrCast(claim);
            return code(.ok);
        }

        pub fn control_tree_claim_read_function(
            handle: ?*anyopaque,
            key_pointer: ?*const ItemKeyView,
            function_pointer: ?*const ReadFunction,
            output_claim: ?*?*anyopaque,
        ) callconv(.c) i32 {
            const output = output_claim orelse return code(.invalid_argument);
            output.* = null;
            const session = castSession(handle) orelse return code(.invalid_argument);
            const key = key_pointer orelse return code(.invalid_argument);
            const function = function_pointer orelse return code(.invalid_argument);
            const claim = switch (session.controller) {
                inline else => |controller| controller.claimReadFunction(key.toKey(), function.*) catch |err| return codeFor(err),
            };
            output.* = @ptrCast(claim);
            return code(.ok);
        }

        pub fn control_tree_notify_changed(
            handle: ?*anyopaque,
            claim_pointer: ?*anyopaque,
            reason_pointer: ?*const ReasonView,
            completion_token: u64,
        ) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            const claim = castClaim(claim_pointer) orelse return code(.invalid_argument);
            const reason = reason_pointer orelse return code(.invalid_argument);
            const token = optionalToken(completion_token);
            return switch (session.controller) {
                inline else => |controller| finish(controller.notifyChanged(claim, reason.toReason(), token)),
            };
        }

        pub fn control_tree_read(
            handle: ?*anyopaque,
            key_pointer: ?*const ItemKeyView,
            output_value: ?*u32,
        ) callconv(.c) i32 {
            const output = output_value orelse return code(.invalid_argument);
            const session = castSession(handle) orelse return code(.invalid_argument);
            const key = key_pointer orelse return code(.invalid_argument);
            const value = switch (session.controller) {
                inline else => |controller| controller.read(key.toKey()) catch |err| return codeFor(err),
            };
            output.* = @backingInt(readToView(value));
            return code(.ok);
        }

        pub fn control_tree_read_presence(
            handle: ?*anyopaque,
            key_pointer: ?*const ItemKeyView,
            output_value: ?*u32,
        ) callconv(.c) i32 {
            const output = output_value orelse return code(.invalid_argument);
            const session = castSession(handle) orelse return code(.invalid_argument);
            const key = key_pointer orelse return code(.invalid_argument);
            const value = switch (session.controller) {
                inline else => |controller| controller.readPresence(key.toKey()) catch |err| return codeFor(err),
            };
            output.* = @backingInt(presenceToView(value));
            return code(.ok);
        }

        pub fn control_tree_read_state(
            handle: ?*anyopaque,
            block_uid: u32,
            output_state: ?*u32,
        ) callconv(.c) i32 {
            const output = output_state orelse return code(.invalid_argument);
            const session = castSession(handle) orelse return code(.invalid_argument);
            const value = switch (session.controller) {
                inline else => |controller| controller.readState(block_uid) catch |err| return codeFor(err),
            };
            output.* = @backingInt(value);
            return code(.ok);
        }

        pub fn control_tree_publish(
            handle: ?*anyopaque,
            claim_pointer: ?*anyopaque,
            value: u32,
            reason_pointer: ?*const ReasonView,
            completion_token: u64,
        ) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            const claim = castClaim(claim_pointer) orelse return code(.invalid_argument);
            const reason = reason_pointer orelse return code(.invalid_argument);
            const publication = readFromView(value) catch return code(.invalid_argument);
            const token = optionalToken(completion_token);
            return switch (session.controller) {
                inline else => |controller| finish(controller.publish(claim, publication, reason.toReason(), token)),
            };
        }

        pub fn control_tree_publish_presence(
            handle: ?*anyopaque,
            claim_pointer: ?*anyopaque,
            value: u32,
            reason_pointer: ?*const ReasonView,
            completion_token: u64,
        ) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            const claim = castClaim(claim_pointer) orelse return code(.invalid_argument);
            const reason = reason_pointer orelse return code(.invalid_argument);
            const publication = presenceFromView(value) catch return code(.invalid_argument);
            const token = optionalToken(completion_token);
            return switch (session.controller) {
                inline else => |controller| finish(controller.publishPresence(claim, publication, reason.toReason(), token)),
            };
        }

        pub fn control_tree_bind(
            handle: ?*anyopaque,
            claim_pointer: ?*anyopaque,
            reason_pointer: ?*const ReasonView,
            completion_token: u64,
        ) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            const claim = castClaim(claim_pointer) orelse return code(.invalid_argument);
            const reason = reason_pointer orelse return code(.invalid_argument);
            const token = optionalToken(completion_token);
            return switch (session.controller) {
                inline else => |controller| finish(controller.bind(claim, reason.toReason(), token)),
            };
        }

        pub fn control_tree_unbind(
            handle: ?*anyopaque,
            claim_pointer: ?*anyopaque,
            reason_pointer: ?*const ReasonView,
            completion_token: u64,
        ) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            const claim = castClaim(claim_pointer) orelse return code(.invalid_argument);
            const reason = reason_pointer orelse return code(.invalid_argument);
            const token = optionalToken(completion_token);
            return switch (session.controller) {
                inline else => |controller| finish(controller.unbind(claim, reason.toReason(), token)),
            };
        }

        pub fn control_tree_register_reader(
            handle: ?*anyopaque,
            key_pointer: ?*const ItemKeyView,
            holder_pointer: ?[*]const u8,
            holder_length: u32,
            output_registration_id: ?*u64,
        ) callconv(.c) i32 {
            const output = output_registration_id orelse return code(.invalid_argument);
            output.* = 0;
            const session = castSession(handle) orelse return code(.invalid_argument);
            const key = key_pointer orelse return code(.invalid_argument);
            const holder = bytesFrom(holder_pointer, holder_length) catch return code(.invalid_argument);
            const registration_id = switch (session.controller) {
                inline else => |controller| controller.registerReader(key.toKey(), holder) catch |err| return codeFor(err),
            };
            output.* = registration_id;
            return code(.ok);
        }

        pub fn control_tree_unregister_reader(handle: ?*anyopaque, registration_id: u64) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            return switch (session.controller) {
                inline else => |controller| finish(controller.unregisterReader(registration_id)),
            };
        }

        pub fn control_tree_run_running(handle: ?*anyopaque, block_uid: u32, run: u64) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            return switch (session.controller) {
                inline else => |controller| finish(controller.reportRunning(block_uid, run)),
            };
        }

        pub fn control_tree_run_returned(handle: ?*anyopaque, block_uid: u32, run: u64) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            return switch (session.controller) {
                inline else => |controller| finish(controller.reportReturned(block_uid, run)),
            };
        }

        pub fn control_tree_shutdown(
            handle: ?*anyopaque,
            reason_pointer: ?*const ReasonView,
            completion_token: u64,
        ) callconv(.c) i32 {
            const session = castSession(handle) orelse return code(.invalid_argument);
            const reason = reason_pointer orelse return code(.invalid_argument);
            const token = optionalToken(completion_token);
            return switch (session.controller) {
                inline else => |controller| finish(controller.shutdown(reason.toReason(), token)),
            };
        }

        /// Writes a complete JSON snapshot when there is room. On a short buffer it
        /// still returns the full byte count through `required_length`.
        pub fn control_tree_snapshot(
            handle: ?*anyopaque,
            buffer_pointer: ?[*]u8,
            buffer_length: usize,
            required_length: ?*usize,
        ) callconv(.c) i32 {
            const required = required_length orelse return code(.invalid_argument);
            required.* = 0;
            const session = castSession(handle) orelse return code(.invalid_argument);
            if (buffer_length > 0 and buffer_pointer == null) return code(.invalid_argument);
            var empty_buffer: [0]u8 = .{};
            const buffer: []u8 = if (buffer_length == 0) empty_buffer[0..] else buffer_pointer.?[0..buffer_length];
            const length = switch (session.controller) {
                inline else => |controller| controller.snapshot(buffer) catch |err| return codeFor(err),
            };
            required.* = length;
            return code(if (length > buffer_length) .buffer_too_small else .ok);
        }
    };
}

fn configFrom(view: *const Config) !control.Config {
    if (view.host_block_count > 0 and view.host_blocks == null) return error.InvalidArgument;
    const host_block_count: usize = @intCast(view.host_block_count);
    const host_blocks = if (host_block_count == 0) &.{} else view.host_blocks.?[0..host_block_count];
    return .{
        .worker_count = view.worker_count,
        .history_capacity = view.history_capacity,
        .completion_capacity = view.completion_capacity,
        .reader_capacity = view.reader_capacity,
        .reader_bytes = view.reader_bytes,
        .worker_arena_bytes = view.worker_arena_bytes,
        .reason_text_capacity = view.reason_text_capacity,
        .shutdown_item = view.shutdown_item_uid,
        .host_blocks = host_blocks,
    };
}

fn hostFrom(view: *const HostCallbacks) ?control.Host {
    return .{
        .context = view.context,
        .start = view.start orelse return null,
        .stop = view.stop orelse return null,
        .complete = view.complete orelse return null,
        .log = view.log orelse return null,
        .item_changed = view.item_changed orelse return null,
    };
}

fn bytesFrom(pointer: ?[*]const u8, length: u32) error{InvalidArgument}![]const u8 {
    if (length == 0) return &.{};
    const data = pointer orelse return error.InvalidArgument;
    return data[0..length];
}

fn readFromView(value: u32) error{InvalidArgument}!control.Read {
    return switch (value) {
        @backingInt(ReadView.not_published) => .not_published,
        @backingInt(ReadView.owner_stopped) => .owner_stopped,
        @backingInt(ReadView.read_failed) => .read_failed,
        @backingInt(ReadView.false_value) => .{ .value = false },
        @backingInt(ReadView.true_value) => .{ .value = true },
        else => error.InvalidArgument,
    };
}

fn presenceFromView(value: u32) error{InvalidArgument}!control.Presence {
    return switch (value) {
        @backingInt(PresenceView.present) => .present,
        @backingInt(PresenceView.not_published) => .not_published,
        @backingInt(PresenceView.owner_stopped) => .owner_stopped,
        @backingInt(PresenceView.read_failed) => .read_failed,
        else => error.InvalidArgument,
    };
}

fn readToView(value: control.Read) ReadView {
    return switch (value) {
        .not_published => .not_published,
        .owner_stopped => .owner_stopped,
        .read_failed => .read_failed,
        .value => |boolean| if (boolean) .true_value else .false_value,
    };
}

fn presenceToView(value: control.Presence) PresenceView {
    return switch (value) {
        .present => .present,
        .not_published => .not_published,
        .owner_stopped => .owner_stopped,
        .read_failed => .read_failed,
    };
}

fn optionalToken(value: u64) ?u64 {
    return if (value == 0) null else value;
}

fn castClaim(claim: ?*anyopaque) ?control.state.Claim {
    return @ptrCast(claim orelse return null);
}

fn finish(result: anyerror!void) i32 {
    result catch |err| return codeFor(err);
    return code(.ok);
}

pub fn codeFor(err: anyerror) i32 {
    return code(switch (err) {
        error.OutOfMemory => .out_of_memory,
        error.InvalidArgument => .invalid_argument,
        error.AbiMismatch => .abi_mismatch,
        error.ThreadQuotaExceeded,
        error.SystemResources,
        error.LockedMemoryLimitExceeded,
        error.Unexpected,
        => .unavailable,
        error.InvalidConfiguration => .control_invalid_configuration,
        error.HostBlocksMismatch => .control_host_blocks_mismatch,
        error.UnregisteredItem => .control_undeclared_item,
        error.UnregisteredBlock => .control_unregistered_block,
        error.StorageMismatch => .control_storage_mismatch,
        error.AlreadyClaimed => .control_duplicate_claim,
        error.InvalidClaim => .control_invalid_claim,
        error.TypeMismatch => .control_type_mismatch,
        error.NotActive => .control_not_active,
        error.CompletionFull => .control_completion_full,
        error.InvalidReason => .invalid_argument,
        error.ReasonTooLong => .control_reason_too_long,
        error.InvalidHolder => .control_invalid_holder,
        error.DuplicateHolder => .control_duplicate_reader,
        error.ReaderFull => .control_reader_full,
        error.NotShuttingDown => .control_not_shutting_down,
        error.RunsActive => .control_runs_active,
        else => @panic("unmapped control_tree ABI error; fail fast rather than hide a controller defect"),
    });
}

pub fn code(result: ResultCode) i32 {
    return @backingInt(result);
}

pub const symbol_names = [_][:0]const u8{
    "control_tree_abi_version",
    "control_tree_configuration_host_blocks",
    "control_tree_create",
    "control_tree_activate",
    "control_tree_destroy",
    "control_tree_claim_write",
    "control_tree_claim_cell",
    "control_tree_claim_read_function",
    "control_tree_notify_changed",
    "control_tree_read",
    "control_tree_read_presence",
    "control_tree_read_state",
    "control_tree_publish",
    "control_tree_publish_presence",
    "control_tree_bind",
    "control_tree_unbind",
    "control_tree_register_reader",
    "control_tree_unregister_reader",
    "control_tree_run_running",
    "control_tree_run_returned",
    "control_tree_shutdown",
    "control_tree_snapshot",
};
