#ifndef CONTROL_TREE_H
#define CONTROL_TREE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CONTROL_TREE_ABI_VERSION UINT32_C(0x00010000)

/* Configuration ids are defined by the consumer's Zig root.
 * Block, item and condition UIDs belong to its versioned registry. */
typedef void *control_tree_handle;
typedef void *control_tree_claim;

typedef enum control_tree_result {
    CONTROL_TREE_OK = 0,
    CONTROL_TREE_INVALID_ARGUMENT = 1,
    CONTROL_TREE_ABI_MISMATCH = 2,
    CONTROL_TREE_UNAVAILABLE = 3,
    CONTROL_TREE_NO_DATA = 4,
    CONTROL_TREE_BUFFER_TOO_SMALL = 5,
    CONTROL_TREE_STALE_FRAME = 6,
    CONTROL_TREE_OUT_OF_MEMORY = 7,
    CONTROL_TREE_DUPLICATE_CLAIM = 20,
    CONTROL_TREE_UNDECLARED_ITEM = 21,
    CONTROL_TREE_TYPE_MISMATCH = 22,
    CONTROL_TREE_HOST_BLOCKS_MISMATCH = 24,
    CONTROL_TREE_INVALID_CONFIGURATION = 25,
    CONTROL_TREE_DUPLICATE_READER = 26,
    CONTROL_TREE_READER_FULL = 27,
    CONTROL_TREE_COMPLETION_FULL = 28,
    CONTROL_TREE_INVALID_CLAIM = 29,
    CONTROL_TREE_STORAGE_MISMATCH = 30,
    CONTROL_TREE_NOT_ACTIVE = 31,
    CONTROL_TREE_REASON_TOO_LONG = 34,
    CONTROL_TREE_NOT_SHUTTING_DOWN = 35,
    CONTROL_TREE_RUNS_ACTIVE = 36,
    CONTROL_TREE_UNREGISTERED_BLOCK = 37,
    CONTROL_TREE_INVALID_HOLDER = 38
} control_tree_result;

typedef enum control_tree_read_value {
    CONTROL_TREE_READ_NOT_PUBLISHED = 0,
    CONTROL_TREE_READ_OWNER_STOPPED = 1,
    CONTROL_TREE_READ_FAILED = 2,
    CONTROL_TREE_READ_FALSE = 3,
    CONTROL_TREE_READ_TRUE = 4
} control_tree_read_value;

typedef enum control_tree_presence_value {
    CONTROL_TREE_PRESENT = 0,
    CONTROL_TREE_PRESENCE_NOT_PUBLISHED = 1,
    CONTROL_TREE_PRESENCE_OWNER_STOPPED = 2,
    CONTROL_TREE_PRESENCE_READ_FAILED = 3
} control_tree_presence_value;

typedef enum control_tree_block_state {
    CONTROL_TREE_STOPPED = 0,
    CONTROL_TREE_STARTING = 1,
    CONTROL_TREE_RUNNING = 2,
    CONTROL_TREE_STOPPING = 3
} control_tree_block_state;

typedef struct control_tree_config {
    uint32_t struct_size;
    uint32_t configuration;
    uint32_t worker_count;
    uint32_t history_capacity;
    uint32_t completion_capacity;
    uint32_t reader_capacity;
    uint32_t reader_bytes;
    uint32_t worker_arena_bytes;
    uint32_t reason_text_capacity;
    uint32_t shutdown_item_uid;
    const uint32_t *host_blocks;
    uint32_t host_block_count;
} control_tree_config;

/* block == 0 denotes an item with one value, independent of any block. */
typedef struct control_tree_item_key {
    uint32_t item;
    uint32_t block;
} control_tree_item_key;

/* UTF-8 byte spans are borrowed for the duration of a call. */
typedef struct control_tree_reason {
    uint32_t kind;
    const uint8_t *owner;
    size_t owner_length;
    const uint8_t *cause;
    size_t cause_length;
    uint64_t plan_version;
} control_tree_reason;

/* Read-function output: kind 0/1/2 means absent/owner stopped/read failed;
 * kind 3 means boolean, with value 0 or 1. Invalid output becomes read failed. */
typedef struct control_tree_function_read {
    uint32_t kind;
    uint32_t value;
} control_tree_function_read;

typedef struct control_tree_read_function {
    void *context;
    void (*read)(void *context, control_tree_function_read *output);
} control_tree_read_function;

/* Exactly five callbacks, all required. They run without controller locks and
 * may reenter. Queue work and return immediately. A read function is a separate
 * synchronous current-value accessor, not a sixth event callback. Keep its
 * context alive until destroy, including after unbind. */
typedef struct control_tree_host_callbacks {
    void *context;
    void (*start)(void *context, uint32_t block_uid, uint64_t run);
    void (*stop)(void *context, uint32_t block_uid, uint64_t run);
    void (*complete)(void *context, uint64_t token);
    void (*log)(void *context, uint32_t level, const uint8_t *text, size_t length);
    void (*item_changed)(void *context, uint64_t registration_id,
                         control_tree_item_key key, const control_tree_reason *reason);
} control_tree_host_callbacks;

uint32_t control_tree_abi_version(void);
/* Counts are UIDs, not bytes. A short buffer is untouched.
 * A null buffer is accepted when the required count is zero. */
int32_t control_tree_configuration_host_blocks(uint32_t configuration, uint32_t *buffer,
                                               size_t capacity, size_t *needed);
int32_t control_tree_create(const control_tree_config *config,
                           const control_tree_host_callbacks *callbacks, control_tree_handle *output);
int32_t control_tree_activate(control_tree_handle handle);
/* Only after shutdown and after every run returned; otherwise handle stays valid. */
int32_t control_tree_destroy(control_tree_handle handle);
int32_t control_tree_claim_write(control_tree_handle, const control_tree_item_key *, control_tree_claim *);
int32_t control_tree_claim_cell(control_tree_handle, const control_tree_item_key *, control_tree_claim *);
int32_t control_tree_claim_read_function(control_tree_handle, const control_tree_item_key *,
                                       const control_tree_read_function *, control_tree_claim *);
int32_t control_tree_notify_changed(control_tree_handle, control_tree_claim, const control_tree_reason *, uint64_t token);
int32_t control_tree_read(control_tree_handle, const control_tree_item_key *, uint32_t *output);
int32_t control_tree_read_presence(control_tree_handle, const control_tree_item_key *, uint32_t *output);
int32_t control_tree_read_state(control_tree_handle, uint32_t block_uid, uint32_t *output);
/* token == 0 means no completion callback. */
int32_t control_tree_publish(control_tree_handle, control_tree_claim, uint32_t value, const control_tree_reason *, uint64_t token);
int32_t control_tree_publish_presence(control_tree_handle, control_tree_claim, uint32_t presence, const control_tree_reason *, uint64_t token);
int32_t control_tree_bind(control_tree_handle, control_tree_claim, const control_tree_reason *, uint64_t token);
int32_t control_tree_unbind(control_tree_handle, control_tree_claim, const control_tree_reason *, uint64_t token);
int32_t control_tree_register_reader(control_tree_handle, const control_tree_item_key *, const uint8_t *holder,
                                    uint32_t holder_length, uint64_t *registration_id);
int32_t control_tree_unregister_reader(control_tree_handle, uint64_t registration_id);
/* Non-current run numbers are ignored. Late running cannot undo stop. */
int32_t control_tree_run_running(control_tree_handle, uint32_t block_uid, uint64_t run);
int32_t control_tree_run_returned(control_tree_handle, uint32_t block_uid, uint64_t run);
int32_t control_tree_shutdown(control_tree_handle, const control_tree_reason *, uint64_t token);
/* No terminator. required is the complete UTF-8 byte count even on short buffers. */
int32_t control_tree_snapshot(control_tree_handle, uint8_t *buffer, size_t capacity, size_t *required);

#ifdef __cplusplus
}
#endif
#endif
