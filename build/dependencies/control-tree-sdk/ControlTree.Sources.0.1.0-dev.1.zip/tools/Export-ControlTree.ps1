#Requires -Version 7.4
[CmdletBinding()]
param([string[]]$TreeJson,[string]$Registry,[string]$From='Program',[string]$Profile,
    [ValidateSet('text','json')][string]$Format='text',[string]$CompareWith,
    [string]$Zig,[string]$JobQueue,[string]$WorkRoot=(Join-Path $PSScriptRoot '../.local/export'),
    [ValidateNotNullOrEmpty()][string]$ScratchDirectory,
    [string]$Process,[string]$ExportDirectory,[string]$ExportStep,[string[]]$ExportArguments,
    [ValidateRange(1,2147483647)][long]$MaxInputBytes=64MB,[ValidateRange(1,65536)][int]$MaxProcessFiles=64,
    [ValidateRange(1,100000)][int]$MaxNodes=100000,[ValidateRange(1,4096)][int]$MaxDepth=4096,
    [ValidateRange(1,1440)][int]$TimeoutMinutes=30,[ValidateRange(1,1024)][int]$MemoryLimitGiB=6)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
function Read-BoundedText([string]$Path) {
    $file=Get-Item -LiteralPath $Path
    if ($file.PSIsContainer -or $file.Length -gt $MaxInputBytes) { throw "Expected a file of at most $MaxInputBytes bytes: $Path" }
    [IO.File]::ReadAllText($file.FullName,[Text.UTF8Encoding]::new($false,$true))
}
function Read-Source([string]$Text) { ConvertFrom-Json -InputObject $Text -AsHashtable -Depth 64 }
function Invoke-ProcessExport([string]$ProcessName,$Config,[string]$RegistryRoot,[string]$Scratch) {
    $directory=if ($ExportDirectory) { [IO.Path]::GetFullPath($ExportDirectory) } else { [IO.Path]::GetFullPath((Join-Path $RegistryRoot $Config.directory)) }
    $step=if ($ExportStep) { $ExportStep } else { $Config.step }
    $extra=@(if ($script:exportArgumentsOverridden) { $ExportArguments } else { $Config.arguments })
    if ($step -cnotmatch '^[A-Za-z_][A-Za-z0-9_-]*$') { throw 'Invalid export step override.' }
    if ($extra.Count -gt 128) { throw 'Too many export arguments.' }
    $i=0
    while ($i -lt $extra.Count) { if ($extra[$i++] -match '^(-j|--cache-dir|--global-cache)') { throw 'Export arguments cannot override job/cache controls.' } }
    $arguments=@('build',$step)+$extra+@('-j1','--cache-dir',(Join-Path $Scratch "$ProcessName-cache"))
    $hostExe=Join-Path $PSHOME $(if ($IsWindows) { 'pwsh.exe' } else { 'pwsh' })
    $hadGlobalCache=Test-Path -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR
    $originalGlobalCache=$env:ZIG_GLOBAL_CACHE_DIR
    try {
        $env:ZIG_GLOBAL_CACHE_DIR=Join-Path $Scratch 'global-cache'
        $resultLines=@(& $hostExe -NoProfile -CommandWithArgs '& $args[0] -Action Run -Label "control-tree export" -FilePath $args[1] -WorkingDirectory $args[2] -TimeoutMinutes ([int]$args[3]) -MemoryLimitGiB ([int]$args[4]) -ArgumentList $args[5..($args.Count-1)]' $JobQueue $Zig $directory $TimeoutMinutes $MemoryLimitGiB @arguments)
        $code=$LASTEXITCODE
    } finally {
        if ($hadGlobalCache) { $env:ZIG_GLOBAL_CACHE_DIR=$originalGlobalCache }
        else { Remove-Item -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR -ErrorAction SilentlyContinue }
    }
    if ($resultLines.Count -eq 0) { throw "JobQueue returned no result for $ProcessName." }
    $result=Read-Source $resultLines[-1]
    if ($code -ne 0) {
        $message=if ($result.Contains('errorLog') -and (Test-Path -LiteralPath $result.errorLog)) { Read-BoundedText $result.errorLog } else { "exit $code" }
        throw "Export failed for ${ProcessName}: $message"
    }
    $source=Read-Source (Read-BoundedText $result.log)
    if ($source.process -cne $ProcessName) { throw "Expected process $ProcessName from JobQueue." }
    $source
}
function Get-TargetTree([string]$Path) {
    $text=Read-BoundedText $Path
    $fence=[regex]::Match($text,'(?ms)^```control-tree\s*\r?\n(.*?)^```\s*$')
    if ($fence.Success) { $text=$fence.Groups[1].Value }
    elseif ([IO.Path]::GetExtension($Path) -in @('.md','.markdown')) { throw 'No control-tree fenced block.' }
    $target=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
    $ancestors=[Collections.Generic.List[string]]::new(); $lines=$text -split '\r?\n'; $i=0
    while ($i -lt $lines.Count) {
        $line=$lines[$i++]; if ([string]::IsNullOrWhiteSpace($line)) { continue }
        if ($target.Count -ge $MaxNodes) { throw 'Target node limit exceeded.' }
        if ($line -notmatch '^(?<indent>(?:(?:│  |   ))*)(?:(?<branch>├─ |└─ ))?(?<name>[^\s]+)(?:  .*)?$') { throw "Invalid tree line: $line" }
        $depth=[int]($Matches.indent.Length/3)
        if ($Matches.ContainsKey('branch') -and $Matches.branch) { $depth++ }
        $name=$Matches.name
        if ($depth -gt $MaxDepth -or $depth -gt $ancestors.Count -or ($depth -eq 0 -and $target.Count -gt 0)) { throw "Invalid indentation: $line" }
        if ($target.ContainsKey($name)) { throw "Duplicate target block: $name" }
        $parent=if ($depth -eq 0) { $null } else { $ancestors[$depth-1] }
        $target.Add($name,$parent)
        while ($ancestors.Count -gt $depth) { $ancestors.RemoveAt($ancestors.Count-1) }
        $ancestors.Add($name)
    }
    if ($target.Count -eq 0) { throw 'Target tree is empty.' }
    ,$target
}

$sources=[Collections.Generic.List[object]]::new()
$script:exportArgumentsOverridden=$PSBoundParameters.ContainsKey('ExportArguments')
if ($PSBoundParameters.ContainsKey('TreeJson')) {
    if ($TreeJson.Count -lt 1 -or $TreeJson.Count -gt $MaxProcessFiles) { throw "Provide 1..$MaxProcessFiles TreeJson files." }
    $i=0
    while ($i -lt $TreeJson.Count) { $sources.Add((Read-Source (Read-BoundedText $TreeJson[$i++]))) }
} else {
    if (-not $Registry -or -not $JobQueue) { throw 'Automatic export requires Registry and JobQueue.' }
    if (($ExportDirectory -or $ExportStep -or $script:exportArgumentsOverridden) -and -not $Process) { throw 'Export overrides require one Process.' }
    if (-not $Zig) { $Zig=(Get-Command zig -CommandType Application -ErrorAction Stop).Source }
    if (-not (Test-Path -LiteralPath $Zig -PathType Leaf) -or -not (Test-Path -LiteralPath $JobQueue -PathType Leaf)) { throw 'Zig/JobQueue must identify existing files.' }
    Import-Module (Join-Path $PSScriptRoot 'StateItemRegistry.psm1') -Force
    $registryPath=[IO.Path]::GetFullPath($Registry); $table=Read-StateRegistry -Path $registryPath
    $names=@($table.processes.Keys)
    if ($Process -and $Process -cnotin $names) { throw "Unknown process $Process." }
    $scratch=if ($ScratchDirectory) { [IO.Path]::GetFullPath($ScratchDirectory) } else { Join-Path ([IO.Path]::GetFullPath($WorkRoot)) ([guid]::NewGuid().ToString('N')) }
    $null=[IO.Directory]::CreateDirectory($scratch); $i=0
    while ($i -lt $names.Count) {
        $name=$names[$i++]; if ($Process -and $name -cne $Process) { continue }
        $spec=$table.processes[$name]
        if (-not $spec.Contains('export')) { throw "Process $name has no export configuration." }
        $sources.Add((Invoke-ProcessExport $name $spec.export ([IO.Path]::GetDirectoryName($registryPath)) $scratch))
    }
}
$processes=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
$allBlocks=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
$nodes=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
$nodes.Add('Program',@{id='Program';process=$null;uid=$null;name='Program';parent=$null;children=[Collections.Generic.List[string]]::new();profiles=@();declarations=@();active=$true})
$profileFound=-not $Profile; $i=0
while ($i -lt $sources.Count) {
    $source=$sources[$i++]
    if ($source -isnot [Collections.IDictionary] -or $source['schemaVersion'] -ne 1 -or $source['process'] -cnotmatch '^[A-Za-z_][A-Za-z0-9_.-]*$' -or $source['blocks'] -isnot [array] -or $source['profiles'] -isnot [array]) { throw 'Invalid process export header.' }
    $name=$source.process
    if (-not $processes.TryAdd($name,$source)) { throw "Duplicate process $name." }
    if ($Profile -cin $source.profiles) { $profileFound=$true }
    $rootFound=$false; $j=0; $blockNames=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    while ($j -lt $source.blocks.Count) {
        $block=$source.blocks[$j++]
        if ($allBlocks.Count -ge $MaxNodes) { throw 'Node limit exceeded.' }
        if ($block -isnot [Collections.IDictionary] -or $block['uid'] -isnot [long] -or $block.uid -le 0 -or $block.uid -gt [uint32]::MaxValue -or $block['name'] -cnotmatch '^[A-Za-z_][A-Za-z0-9_]*$' -or $block['declarations'] -isnot [array] -or -not $block.Contains('parent')) { throw 'Invalid block name/UID/declarations.' }
        if (-not $blockNames.Add($block.name)) { throw "Duplicate block name in $name." }
        $key="${name}:$($block.uid)"
        if (-not $allBlocks.TryAdd($key,$block)) { throw "Duplicate block $key." }
        if ($block.uid -eq $source.program) {
            if ($null -ne $block.parent) { throw 'Process root has a parent.' }
            $rootFound=$true; continue
        }
        if ($null -eq $block.parent) { throw 'Non-program block has no parent.' }
        $selected=[Collections.Generic.List[object]]::new(); $k=0
        while ($k -lt $block.declarations.Count) {
            $declaration=$block.declarations[$k++]
            if ($declaration -isnot [Collections.IDictionary] -or $declaration['profile'] -cnotin $source.profiles) { throw 'Declaration references an unknown profile.' }
            if (-not $Profile -or $declaration.profile -ceq $Profile) { $selected.Add($declaration) }
        }
        $profileNames=[Collections.Generic.List[string]]::new(); $k=0
        while ($k -lt $selected.Count) { $profileNames.Add($selected[$k++].profile) }
        $nodes.Add($key,@{id="${name}:$($block.name)";process=$name;uid=$block.uid;name=$block.name;parent="${name}:$($block.parent)";children=[Collections.Generic.List[string]]::new();profiles=$profileNames.ToArray();declarations=$selected.ToArray();active=($selected.Count -gt 0)})
    }
    if (-not $rootFound) { throw "Missing program root for $name." }
}
if (-not $profileFound) { throw "Unknown profile $Profile." }
$launchers=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal); $i=0; $declarationCount=0
while ($i -lt $sources.Count) {
    $source=$sources[$i++]; $j=0
    while ($j -lt $source.blocks.Count) {
        $block=$source.blocks[$j++]; $key="$($source.process):$($block.uid)"; $k=0
        while ($k -lt $block.declarations.Count) {
            if (++$declarationCount -gt 1000000) { throw 'Declaration limit exceeded.' }
            $declaration=$block.declarations[$k++]; $launch=$declaration['launchesProcess']
            if ($null -eq $launch) { continue }
            if (-not $processes.ContainsKey($launch)) { throw "Unknown launched process $launch." }
            if ($block.uid -eq $source.program) { throw 'Process root cannot launch a process.' }
            if ($launchers.ContainsKey($launch) -and $launchers[$launch] -cne $key) { throw "Process $launch launched twice." }
            $launchers[$launch]=$key
        }
    }
}
$keys=@($nodes.Keys); $i=0
while ($i -lt $keys.Count) {
    $key=$keys[$i++]; if ($key -ceq 'Program') { continue }
    $node=$nodes[$key]; $source=$processes[$node.process]
    if ($node.parent -ceq "$($node.process):$($source.program)") {
        $node.parent=if ($launchers.ContainsKey($node.process)) { $launchers[$node.process] } else { 'Program' }
        if ($Profile -and $launchers.ContainsKey($node.process)) {
            $activeLaunch=$false; $decls=$nodes[$node.parent].declarations; $j=0
            while ($j -lt $decls.Count) { if ($decls[$j++]['launchesProcess'] -ceq $node.process) { $activeLaunch=$true } }
            if (-not $activeLaunch) { $node.active=$false }
        }
    }
    if (-not $nodes.ContainsKey($node.parent)) { throw "Unknown parent $($node.parent) for $($node.id)." }
    $nodes[$node.parent].children.Add($key)
}
# Validate the complete declaration graph, including profile-excluded branches.
$colour=@{}; $i=0; $remaining=3L*$nodes.Count
while ($i -lt $keys.Count) {
    $cursor=$keys[$i++]; $chain=[Collections.Generic.List[string]]::new()
    while ($null -ne $cursor -and -not $colour.ContainsKey($cursor)) {
        if ($remaining-- -le 0 -or $chain.Count -gt $MaxDepth) { throw 'Tree depth/traversal bound exceeded.' }
        $colour[$cursor]=1; $chain.Add($cursor); $cursor=$nodes[$cursor].parent
    }
    if ($null -ne $cursor -and $colour[$cursor] -eq 1) { throw "Control tree cycle at $($nodes[$cursor].id)." }
    $j=$chain.Count-1
    while ($j -ge 0) { $colour[$chain[$j--]]=2 }
}
$reachable=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$pending=[Collections.Generic.Stack[object]]::new(); $pending.Push(@{key='Program';depth=0})
while ($pending.Count -gt 0) {
    $frame=$pending.Pop(); $node=$nodes[$frame.key]
    if (-not $node.active) { continue }
    if ($frame.depth -gt $MaxDepth -or -not $reachable.Add($frame.key)) { throw 'Reachability bound/cycle exceeded.' }
    $j=$node.children.Count-1
    while ($j -ge 0) { $pending.Push(@{key=$node.children[$j--];depth=$frame.depth+1}) }
}
$selection=$From; $i=0
while ($i -lt $sources.Count) {
    $source=$sources[$i++]; $root=$allBlocks["$($source.process):$($source.program)"]
    if ($From -ceq "$($source.process):$($source.program)" -or $From -ceq "$($source.process):$($root.name)") { $selection='Program' }
}
$matches=[Collections.Generic.List[string]]::new(); $i=0
while ($i -lt $keys.Count) { $key=$keys[$i++]; $node=$nodes[$key]; if ($reachable.Contains($key) -and ($key -ceq $selection -or $node.id -ceq $selection -or $node.name -ceq $selection)) { $matches.Add($key) } }
if ($matches.Count -ne 1) { throw "From '$From' must identify exactly one block; matches $($matches.Count)." }
$chosen=$matches[0]; $ordered=[Collections.Generic.List[object]]::new()
$pending.Push(@{key=$chosen;prefix='';branch='';depth=0;parent=$null})
while ($pending.Count -gt 0) {
    $frame=$pending.Pop(); $node=$nodes[$frame.key]; $ordered.Add(@{node=$node;prefix=$frame.prefix;branch=$frame.branch;parent=$frame.parent})
    if ($ordered.Count -gt $MaxNodes+1 -or $frame.depth -gt $MaxDepth) { throw 'Output traversal bound exceeded.' }
    $children=[Collections.Generic.List[string]]::new(); $j=0
    while ($j -lt $node.children.Count) { $child=$node.children[$j++]; if ($reachable.Contains($child)) { $children.Add($child) } }
    $j=$children.Count-1
    while ($j -ge 0) {
        $prefix=$frame.prefix
        if ($frame.depth -gt 0) { $prefix+=$(if ($frame.branch -ceq '└─ ') { '   ' } else { '│  ' }) }
        $pending.Push(@{key=$children[$j];prefix=$prefix;branch=$(if ($j -eq $children.Count-1) { '└─ ' } else { '├─ ' });depth=$frame.depth+1;parent=$node.id}); $j--
    }
}
if ($CompareWith) {
    $target=Get-TargetTree $CompareWith; $actual=[Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal); $i=0
    while ($i -lt $ordered.Count) { $entry=$ordered[$i++]; $actual.Add($entry.node.id,$entry.parent) }
    $missing=[Collections.Generic.List[string]]::new(); $extra=[Collections.Generic.List[string]]::new(); $moved=[Collections.Generic.List[object]]::new()
    $targetKeys=@($target.Keys); $i=0
    while ($i -lt $targetKeys.Count) { $key=$targetKeys[$i++]; if (-not $actual.ContainsKey($key)) { $missing.Add($key) } }
    $actualKeys=@($actual.Keys); $i=0
    while ($i -lt $actualKeys.Count) {
        $key=$actualKeys[$i++]
        if (-not $target.ContainsKey($key)) { $extra.Add($key) }
        elseif ($actual[$key] -cne $target[$key]) { $moved.Add([ordered]@{block=$key;targetParent=$target[$key];codeParent=$actual[$key]}) }
    }
    if ($Format -eq 'json') { [ordered]@{missingInCode=$missing.ToArray();extraInCode=$extra.ToArray();parentDiffers=$moved.ToArray()} | ConvertTo-Json -Depth 8 }
    else {
        'Blocks in target but not in code:'; $i=0; while ($i -lt $missing.Count) { '  '+$missing[$i++] }
        'Blocks in code but not in target:'; $i=0; while ($i -lt $extra.Count) { '  '+$extra[$i++] }
        'Blocks whose parent differs:'; $i=0; while ($i -lt $moved.Count) { $move=$moved[$i++]; "  $($move.block): target=$($move.targetParent); code=$($move.codeParent)" }
    }
} elseif ($Format -eq 'json') {
    $rows=[Collections.Generic.List[object]]::new(); $i=0
    while ($i -lt $ordered.Count) {
        $entry=$ordered[$i++]; $node=$entry.node; $children=[Collections.Generic.List[string]]::new(); $j=0
        while ($j -lt $node.children.Count) { $key=$node.children[$j++]; if ($reachable.Contains($key)) { $children.Add($nodes[$key].id) } }
        $rows.Add([ordered]@{id=$node.id;process=$node.process;uid=$node.uid;name=$node.name;parent=$entry.parent;children=$children.ToArray();profiles=$node.profiles;declarations=$node.declarations})
    }
    $metadata=[Collections.Generic.List[object]]::new(); $i=0
    while ($i -lt $sources.Count) { $source=$sources[$i++]; $metadata.Add([ordered]@{process=$source.process;registryVersion=$source['registryVersion'];program=$source.program;profiles=$source.profiles;conditions=$source['conditions'];programBlock=$allBlocks["$($source.process):$($source.program)"]}) }
    [ordered]@{schemaVersion=1;from=$nodes[$chosen].id;profile=$Profile;processes=$metadata.ToArray();blocks=$rows.ToArray()} | ConvertTo-Json -Depth 64
} else {
    $i=0
    while ($i -lt $ordered.Count) {
        $entry=$ordered[$i++]; $names=[Collections.Generic.List[string]]::new(); $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal); $j=0
        while ($j -lt $entry.node.declarations.Count) { $declaration=$entry.node.declarations[$j++]; if ($null -ne $declaration['decidingCondition'] -and $seen.Add($declaration.decidingCondition.name)) { $names.Add($declaration.decidingCondition.name) } }
        $comment=if ($names.Count -gt 0) { '  '+($names -join ' / ') } else { '' }
        "$($entry.prefix)$($entry.branch)$($entry.node.id)$comment"
    }
}
