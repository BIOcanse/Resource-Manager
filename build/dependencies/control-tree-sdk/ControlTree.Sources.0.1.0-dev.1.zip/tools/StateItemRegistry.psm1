#Requires -Version 7.4
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-StateRegistryVersion {
    param([Parameter(Mandatory)][AllowEmptyCollection()][byte[]]$Bytes)
    $hash = [Security.Cryptography.IncrementalHash]::CreateHash([Security.Cryptography.HashAlgorithmName]::SHA1)
    try {
        $hash.AppendData([Text.Encoding]::UTF8.GetBytes("blob $($Bytes.Length)`0"))
        $hash.AppendData($Bytes)
        [Convert]::ToHexString($hash.GetHashAndReset()).ToLowerInvariant()
    } finally { $hash.Dispose() }
}

function Assert-Fields($Object, [string[]]$Required, [string[]]$Allowed, [string]$Label) {
    if ($Object -isnot [Collections.IDictionary]) { throw "${Label}: expected an object." }
    $i=0
    while ($i -lt $Required.Count) {
        $key=$Required[$i++]
        if (-not $Object.Contains($key)) { throw "${Label}: missing $key." }
    }
    $keys=@($Object.Keys); $i=0
    while ($i -lt $keys.Count) {
        $key=$keys[$i++]
        if ($key -cnotin $Allowed) { throw "${Label}: unknown field $key." }
    }
}

function Assert-Uid($Value, [string]$Label) {
    if (($Value -isnot [long] -and $Value -isnot [int] -and $Value -isnot [bigint]) -or $Value -lt 1 -or $Value -gt [uint32]::MaxValue) {
        throw "${Label}: expected positive uint32 UID."
    }
}

function Assert-Text($Value, [string]$Label) {
    if ($Value -isnot [string] -or [string]::IsNullOrWhiteSpace($Value)) { throw "${Label}: expected non-empty text." }
}

function Get-Reference($Index, $Uid, [string]$Kind, [string]$Process) {
    Assert-Uid $Uid 'Reference'
    $value=$null
    if (-not $Index.TryGetValue([long]$Uid,[ref]$value) -or $value.kind -cne $Kind -or $value.process -cne $Process) {
        throw "UID ${Uid}: unknown $Kind in process $Process."
    }
    $value
}

function Assert-StateRegistry {
    param([Parameter(Mandatory)][Collections.IDictionary]$Registry, [switch]$HistoricalTable)
    Assert-Fields $Registry @('schemaVersion','processes','types','entries') @('schemaVersion','processes','types','entries') 'Registry'
    if ($Registry.schemaVersion -ne 1) { throw 'Registry: unsupported schemaVersion.' }
    if ($Registry.processes -isnot [Collections.IDictionary] -or $Registry.processes.Count -lt 1 -or $Registry.processes.Count -gt 64) { throw 'Registry: processes must contain 1..64 declarations.' }
    if ($Registry.types -isnot [Collections.IDictionary] -or $Registry.types.Count -lt 1 -or $Registry.types.Count -gt 4096) { throw 'Registry: types must contain 1..4096 declarations.' }
    if ($Registry.entries -isnot [array] -or $Registry.entries.Count -gt 100000) { throw 'Registry: entries must be an array of at most 100000 entries.' }
    $processes=@($Registry.processes.Keys); $i=0
    $outputs=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    while ($i -lt $processes.Count) {
        $name=$processes[$i++]; $process=$Registry.processes[$name]
        if ($name -cnotmatch '^[A-Za-z_][A-Za-z0-9_.-]*$') { throw "Invalid process identifier: $name" }
        Assert-Fields $process @('generate') @('generate','export') "Process $name"
        if ($process.generate -isnot [array] -or $process.generate.Count -lt 1 -or $process.generate.Count -gt 32) { throw "Process ${name}: generate must have 1..32 outputs." }
        $zig=$false; $j=0
        while ($j -lt $process.generate.Count) {
            $output=$process.generate[$j++]
            Assert-Fields $output @('language','output') @('language','output','namespace') "Process $name output"
            if ($output.language -cnotin @('Zig','CSharp')) { throw "Process ${name}: unsupported language." }
            Assert-Text $output.output 'Output path'
            if (-not $outputs.Add($output.output)) { throw "Duplicate generation output: $($output.output)" }
            if ($output.language -ceq 'Zig') { $zig=$true }
            if ($output.Contains('namespace') -and ($output.language -cne 'CSharp' -or $output.namespace -cnotmatch '^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$')) { throw 'Invalid CSharp namespace.' }
        }
        if (-not $zig) { throw "Process ${name}: a Zig declaration output is required." }
        if ($process.Contains('export')) {
            Assert-Fields $process.export @('directory','step','arguments') @('directory','step','arguments') "Process $name export"
            Assert-Text $process.export.directory 'Export directory'
            if ($process.export.step -cnotmatch '^[A-Za-z_][A-Za-z0-9_-]*$') { throw 'Invalid export step.' }
            if ($process.export.arguments -isnot [array] -or $process.export.arguments.Count -gt 128) { throw 'Export arguments must be a bounded array.' }
            $j=0
            while ($j -lt $process.export.arguments.Count) {
                $argument=$process.export.arguments[$j++]
                Assert-Text $argument 'Export argument'
                if ($argument -match '^(-j|--cache-dir|--global-cache)') { throw 'Export arguments cannot override job/cache controls.' }
            }
        }
    }
    $types=@($Registry.types.Keys); $i=0
    while ($i -lt $types.Count) {
        $name=$types[$i++]; Assert-Text $name 'Type identifier'
        Assert-Fields $Registry.types[$name] @('valueType') @('valueType') "Type $name"
        if ($Registry.types[$name].valueType -cnotin @('bool','host')) { throw "Type ${name}: unsupported valueType." }
    }
    $uids=[Collections.Generic.Dictionary[long,object]]::new()
    $names=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    $previous=0L; $i=0
    while ($i -lt $Registry.entries.Count) {
        $entry=$Registry.entries[$i++]
        $common=@('uid','kind','process','name','comment')
        if ($entry -isnot [Collections.IDictionary]) { throw 'Entry must be an object.' }
        $extra=switch ($entry['kind']) {
            block { @() }
            item { @('storage','type','owner','perBlock','trigger','changeEvent','pollInterval') }
            condition { @('node','perBlock','items','conditions','children','decides') }
            default { throw 'Unknown entry kind.' }
        }
        Assert-Fields $entry $common @($common + $extra) 'Entry'
        Assert-Uid $entry.uid 'Entry'
        if (-not $uids.TryAdd([long]$entry.uid,$entry)) { throw "Duplicate UID $($entry.uid)." }
        if ($entry.uid -le $previous) { throw 'Entries must be sorted by UID.' }; $previous=$entry.uid
        if ($entry.process -cnotin $processes) { throw "Unknown process $($entry.process)." }
        if ($entry.name -isnot [string] -or $entry.name -cnotmatch '^[A-Za-z_][A-Za-z0-9_]*$') { throw 'Name must be an ASCII identifier.' }
        if (-not $names.Add($entry.process+':'+$entry.name)) { throw "Duplicate name $($entry.name) within process." }
        Assert-Text $entry.comment 'Comment'
        if ($entry.kind -ceq 'item') {
            Assert-Fields $entry @($common+@('storage','type','owner','perBlock','trigger')) @($common+$extra) 'Item'
            if ($entry.storage -cnotin @('own','reference')) { throw 'Unknown storage.' }
            if ($entry.type -cnotin $types) { throw "Unknown type $($entry.type)." }
            if ($entry.perBlock -isnot [bool]) { throw 'perBlock must be boolean.' }
            if ($entry.owner -isnot [Collections.IDictionary] -or $entry.owner.Count -ne 1) { throw 'Item owner must contain exactly block or component.' }
            $ownerKey=@($entry.owner.Keys)[0]
            if ($ownerKey -ceq 'block') { Assert-Uid $entry.owner.block 'Owner' }
            elseif ($ownerKey -ceq 'component') { Assert-Text $entry.owner.component 'Owner component' }
            else { throw 'Unknown owner form.' }
            if ($entry.trigger -ceq 'event') {
                if ($entry.Contains('pollInterval')) { throw 'Event item cannot declare pollInterval.' }
                if (-not $HistoricalTable -or $entry.Contains('changeEvent')) { Assert-Text $entry['changeEvent'] 'changeEvent' }
            } elseif ($entry.trigger -ceq 'poll') {
                if ($entry.Contains('changeEvent')) { throw 'Poll item cannot declare changeEvent.' }
                Assert-Text $entry['pollInterval'] 'pollInterval'
            } else { throw 'Unknown trigger.' }
        } elseif ($entry.kind -ceq 'condition') {
            Assert-Fields $entry @($common+@('perBlock','items','conditions','children')) @($common+$extra) 'Condition'
            if ($entry.perBlock -isnot [bool]) { throw 'perBlock must be boolean.' }
            $fields=@('items','conditions','children'); $j=0
            while ($j -lt $fields.Count) {
                $field=$fields[$j++]
                if ($entry[$field] -isnot [array] -or $entry[$field].Count -gt 100000) { throw "Condition ${field}: expected bounded array." }
            }
            if ($entry.perBlock) {
                if ($entry.Contains('node') -or $entry.Contains('decides') -or $entry.conditions.Count -ne 0 -or $entry.children.Count -ne 0) { throw 'Per-block conditions read items only and omit node/decides.' }
            } elseif (-not $entry.Contains('node')) { throw 'Condition requires node.' }
        }
    }
    $conditions=[Collections.Generic.List[object]]::new(); $i=0; $edgeCount=0L
    while ($i -lt $Registry.entries.Count) {
        $entry=$Registry.entries[$i++]
        if ($entry.kind -ceq 'item' -and $entry.owner.Contains('block')) { $null=Get-Reference $uids $entry.owner.block block $entry.process }
        if ($entry.kind -cne 'condition') { continue }
        $conditions.Add($entry)
        $fields=@('node','decides'); $j=0
        while ($j -lt $fields.Count) { $field=$fields[$j++]; if ($entry.Contains($field)) { $null=Get-Reference $uids $entry[$field] block $entry.process } }
        $j=0
        while ($j -lt $entry.items.Count) {
            $read=$entry.items[$j++]
            Assert-Fields $read @('item') @('item','block') 'Item read'
            $item=Get-Reference $uids $read.item item $entry.process
            if ($Registry.types[$item.type].valueType -ceq 'host') { throw "Condition $($entry.uid) cannot read host item $($item.uid)." }
            if ($read.Contains('block')) {
                $null=Get-Reference $uids $read.block block $entry.process
                if (-not $item.perBlock) { throw 'Only per-block items accept a block selector.' }
            } elseif ($item.perBlock -and -not $entry.perBlock) { throw 'Per-block item requires a block selector.' }
        }
        $j=0
        while ($j -lt $entry.children.Count) { $null=Get-Reference $uids $entry.children[$j++] block $entry.process }
        $j=0
        while ($j -lt $entry.conditions.Count) {
            $lower=Get-Reference $uids $entry.conditions[$j++] condition $entry.process
            if ($entry.perBlock -or $lower.perBlock -or $lower.node -ne $entry.node) { throw 'Lower condition must belong to the same node.' }
            $edgeCount++
            if ($edgeCount -gt 1000000) { throw 'Condition edge limit exceeded.' }
        }
    }
    $colour=@{}; $stack=[Collections.Generic.List[object]]::new(); $remaining=2L*$conditions.Count+$edgeCount; $i=0
    while ($i -lt $conditions.Count) {
        $condition=$conditions[$i++]
        if ($colour.ContainsKey($condition.uid)) { continue }
        $colour[$condition.uid]=1; $stack.Add(@{entry=$condition;next=0})
        while ($stack.Count -gt 0) {
            if ($remaining-- -le 0 -or $stack.Count -gt $conditions.Count) { throw 'Condition traversal bound exceeded.' }
            $frame=$stack[$stack.Count-1]
            if ($frame.next -eq $frame.entry.conditions.Count) { $colour[$frame.entry.uid]=2; $stack.RemoveAt($stack.Count-1); continue }
            $id=$frame.entry.conditions[$frame.next++]
            if ($colour.ContainsKey($id)) { if ($colour[$id] -eq 1) { throw "Condition cycle in node $($frame.entry.node)." } }
            else { $colour[$id]=1; $stack.Add(@{entry=$uids[[long]$id];next=0}) }
        }
    }
}

function Read-StateRegistry {
    [CmdletBinding(DefaultParameterSetName='Path')]
    param([Parameter(Mandatory,ParameterSetName='Path')][string]$Path,
        [Parameter(Mandatory,ParameterSetName='Bytes')][AllowEmptyCollection()][byte[]]$Bytes,[switch]$HistoricalTable,
        [ValidateRange(1,2147483647)][long]$MaxBytes=64MB)
    if ($PSCmdlet.ParameterSetName -eq 'Path') {
        $file=Get-Item -LiteralPath $Path
        if ($file.Length -gt $MaxBytes) { throw "Registry exceeds $MaxBytes bytes." }
        $Bytes=[IO.File]::ReadAllBytes($file.FullName)
    }
    if ($Bytes.Length -gt $MaxBytes) { throw "Registry exceeds $MaxBytes bytes." }
    if ($Bytes.Length -ge 3 -and $Bytes[0] -eq 239 -and $Bytes[1] -eq 187 -and $Bytes[2] -eq 191) { throw 'Registry: BOM forbidden.' }
    if ($Bytes -contains [byte]13) { throw 'Registry: use LF, not CR.' }
    $json=[Text.UTF8Encoding]::new($false,$true).GetString($Bytes)
    $doc=[Text.Json.JsonDocument]::Parse($json)
    try {
        $stack=[Collections.Generic.Stack[Text.Json.JsonElement]]::new(); $stack.Push($doc.RootElement); $remaining=$json.Length+1L
        while ($stack.Count -gt 0) {
            if ($remaining-- -le 0) { throw 'JSON traversal bound exceeded.' }
            $node=$stack.Pop()
            if ($node.ValueKind -eq [Text.Json.JsonValueKind]::Object) {
                $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal); $iterator=$node.EnumerateObject()
                while ($iterator.MoveNext()) {
                    $property=$iterator.Current
                    if (-not $seen.Add($property.Name)) { throw "Duplicate JSON field $($property.Name)." }
                    $stack.Push($property.Value)
                }
            } elseif ($node.ValueKind -eq [Text.Json.JsonValueKind]::Array) {
                $iterator=$node.EnumerateArray()
                while ($iterator.MoveNext()) { $stack.Push($iterator.Current) }
            }
        }
    } finally { $doc.Dispose() }
    $registry=ConvertFrom-Json -InputObject $json -AsHashtable -Depth 64
    Assert-StateRegistry $registry -HistoricalTable:$HistoricalTable
    $registry
}

function ConvertTo-StateRegistryBytes {
    param([Parameter(Mandatory)][Collections.IDictionary]$Registry)
    Assert-StateRegistry $Registry
    ,([Text.UTF8Encoding]::new($false).GetBytes(((ConvertTo-Json -InputObject $Registry -Depth 64) -replace "`r`n","`n")+"`n"))
}

function Write-StateRegistry {
    param([Parameter(Mandatory)][string]$Path,[Parameter(Mandatory)][Collections.IDictionary]$Registry)
    $bytes=ConvertTo-StateRegistryBytes $Registry
    $full=[IO.Path]::GetFullPath($Path); $temporary=$full+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try { [IO.File]::WriteAllBytes($temporary,$bytes); [IO.File]::Move($temporary,$full,$true) }
    finally { if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) } }
}

Export-ModuleMember -Function Get-StateRegistryVersion,Assert-StateRegistry,Read-StateRegistry,ConvertTo-StateRegistryBytes,Write-StateRegistry
