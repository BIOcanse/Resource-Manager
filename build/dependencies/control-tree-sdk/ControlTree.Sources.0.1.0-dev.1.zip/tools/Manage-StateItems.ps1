#Requires -Version 7.4
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('Add','Rename','Remove','Move','SetCondition','SetItem','Resolve','Export')][string]$Action,
    [Parameter(Mandatory)][string]$Registry,
    [ValidateSet('block','item','condition')][string]$Kind,
    [string]$Process,[string]$Name,[string]$Comment,
    [ValidateSet('own','reference')][string]$Storage,[string]$Type,
    [long]$OwnerBlock,[string]$OwnerComponent,[bool]$PerBlock,
    [ValidateSet('event','poll')][string]$Trigger,[string]$ChangeEvent,[string]$PollInterval,
    [long]$Node,[Collections.IDictionary[]]$ItemReads=@(),[long[]]$Conditions=@(),[long[]]$Children=@(),[long]$Decides,
    [long]$Uid,[long[]]$Uids,[string]$Version,[string]$TableDirectory,[string]$Destination
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'StateItemRegistry.psm1') -Force
$registryPath=[IO.Path]::GetFullPath($Registry)
if ($Action -eq 'Resolve' -and $PSBoundParameters.ContainsKey('Version')) {
    if ($Version -cnotmatch '^[0-9a-f]{40}$' -or -not $TableDirectory) { throw 'Versioned Resolve requires lowercase blob SHA1 and TableDirectory.' }
    $bytes=[IO.File]::ReadAllBytes((Join-Path $TableDirectory "$Version.json"))
    if ((Get-StateRegistryVersion $bytes) -cne $Version) { throw 'Historical table blob hash mismatch.' }
    $table=Read-StateRegistry -Bytes $bytes -HistoricalTable
} else { $table=Read-StateRegistry -Path $registryPath }
$index=[Collections.Generic.Dictionary[long,object]]::new(); $i=0
while ($i -lt $table.entries.Count) { $entry=$table.entries[$i++]; $index.Add([long]$entry.uid,$entry) }
function Get-Entry([long]$Id) {
    if ($Id -lt 1 -or -not $index.ContainsKey($Id)) { throw "Registry UID $Id not found." }
    $index[$Id]
}
switch ($Action) {
    Resolve { Get-Entry $Uid | ConvertTo-Json -Depth 64; return }
    Export {
        if (-not $Destination) { throw 'Export requires Destination.' }
        $bytes=[IO.File]::ReadAllBytes($registryPath); $versionId=Get-StateRegistryVersion $bytes
        $path=Join-Path ([IO.Path]::GetFullPath($Destination)) "$versionId.json"
        if ([IO.File]::Exists($path)) {
            if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($path)) -cne [Convert]::ToBase64String($bytes)) { throw 'Immutable published table differs.' }
        } else {
            $null=[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path))
            # CreateNew prevents replacing an existing published table.
            $stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew)
            try { $stream.Write($bytes) } finally { $stream.Dispose() }
        }
        $versionId; return
    }
    Add {
        $required=@('Kind','Process','Name','Comment'); $i=0
        while ($i -lt $required.Count) { $key=$required[$i++]; if (-not $PSBoundParameters.ContainsKey($key)) { throw "Add requires $key." } }
        $next=1L
        while ($next -le $table.entries.Count+1L -and $index.ContainsKey($next)) { $next++ }
        $entry=[ordered]@{uid=$next;kind=$Kind;process=$Process;name=$Name;comment=$Comment}
        $itemFields=@('Storage','Type','OwnerBlock','OwnerComponent','PerBlock','Trigger','ChangeEvent','PollInterval')
        $conditionFields=@('Node','ItemReads','Conditions','Children','Decides')
        $disallowed=if ($Kind -eq 'block') { @($itemFields+$conditionFields) } elseif ($Kind -eq 'item') { $conditionFields } else { @('Storage','Type','OwnerBlock','OwnerComponent','Trigger','ChangeEvent','PollInterval') }
        $i=0
        while ($i -lt $disallowed.Count) { $key=$disallowed[$i++]; if ($PSBoundParameters.ContainsKey($key)) { throw "Add $Kind does not accept $key." } }
        if ($Kind -eq 'item') {
            $required=@('Storage','Type','PerBlock','Trigger'); $i=0
            while ($i -lt $required.Count) { $key=$required[$i++]; if (-not $PSBoundParameters.ContainsKey($key)) { throw "Add item requires $key." } }
            if ($PSBoundParameters.ContainsKey('OwnerBlock') -eq $PSBoundParameters.ContainsKey('OwnerComponent')) { throw 'Item requires exactly one owner form.' }
            $entry.storage=$Storage; $entry.type=$Type; $entry.perBlock=$PerBlock; $entry.trigger=$Trigger
            $entry.owner=if ($PSBoundParameters.ContainsKey('OwnerBlock')) { [ordered]@{block=$OwnerBlock} } else { [ordered]@{component=$OwnerComponent} }
            if ($PSBoundParameters.ContainsKey('ChangeEvent')) { $entry.changeEvent=$ChangeEvent }
            if ($PSBoundParameters.ContainsKey('PollInterval')) { $entry.pollInterval=$PollInterval }
        } elseif ($Kind -eq 'condition') {
            if (-not $PSBoundParameters.ContainsKey('PerBlock')) { throw 'Condition requires PerBlock.' }
            $entry.perBlock=$PerBlock; $entry.items=@($ItemReads); $entry.conditions=@($Conditions); $entry.children=@($Children)
            if ($PSBoundParameters.ContainsKey('Node')) { $entry.node=$Node }
            if ($PSBoundParameters.ContainsKey('Decides')) { $entry.decides=$Decides }
        }
        $table.entries=@(@($table.entries)+@($entry) | Sort-Object { $_['uid'] })
        Write-StateRegistry $registryPath $table
        $next; return
    }
    Rename {
        $entry=Get-Entry $Uid
        if ([string]::IsNullOrWhiteSpace($Name)) { throw 'Rename requires Name.' }
        $entry.name=$Name
        if ($PSBoundParameters.ContainsKey('Comment')) { $entry.comment=$Comment }
    }
    Remove {
        if (-not $Uids -or $Uids.Count -eq 0) { throw 'Remove requires Uids.' }
        $selected=[Collections.Generic.HashSet[long]]::new(); $i=0
        while ($i -lt $Uids.Count) { $id=$Uids[$i++]; $null=Get-Entry $id; if (-not $selected.Add($id)) { throw 'Duplicate selected UID.' } }
        $survivors=[Collections.Generic.List[object]]::new(); $i=0
        while ($i -lt $table.entries.Count) { $entry=$table.entries[$i++]; if (-not $selected.Contains([long]$entry.uid)) { $survivors.Add($entry) } }
        $table.entries=@($survivors.ToArray())
    }
    Move {
        if (-not $Process -or -not $Uids -or $Uids.Count -eq 0) { throw 'Move requires Process and Uids.' }
        $selected=[Collections.Generic.HashSet[long]]::new(); $i=0
        while ($i -lt $Uids.Count) { $id=$Uids[$i++]; if (-not $selected.Add($id)) { throw 'Duplicate selected UID.' }; (Get-Entry $id).process=$Process }
    }
    SetItem {
        $entry=Get-Entry $Uid
        if ($entry.kind -cne 'item') { throw 'SetItem requires an item.' }
        if ($PSBoundParameters.ContainsKey('OwnerBlock') -and $PSBoundParameters.ContainsKey('OwnerComponent')) { throw 'Specify one owner form.' }
        $allowed=@('Action','Registry','Uid','Comment','OwnerBlock','OwnerComponent','ChangeEvent','Type'); $keys=@($PSBoundParameters.Keys); $i=0
        while ($i -lt $keys.Count) { $key=$keys[$i++]; if ($key -notin $allowed) { throw "SetItem does not accept $key." } }
        $changed=$false; $fields=@('Comment','ChangeEvent','Type'); $i=0
        while ($i -lt $fields.Count) { $key=$fields[$i++]; if ($PSBoundParameters.ContainsKey($key)) { $field=$key.Substring(0,1).ToLowerInvariant()+$key.Substring(1); $entry[$field]=$PSBoundParameters[$key]; $changed=$true } }
        if ($PSBoundParameters.ContainsKey('OwnerBlock')) { $entry.owner=[ordered]@{block=$OwnerBlock}; $changed=$true }
        if ($PSBoundParameters.ContainsKey('OwnerComponent')) { $entry.owner=[ordered]@{component=$OwnerComponent}; $changed=$true }
        if (-not $changed) { throw 'SetItem requires a changed field.' }
    }
    SetCondition {
        $entry=Get-Entry $Uid
        if ($entry.kind -cne 'condition') { throw 'SetCondition requires a condition.' }
        $fields=@{Node='node';ItemReads='items';Conditions='conditions';Children='children';Decides='decides';Comment='comment'}; $keys=@($fields.Keys); $i=0; $changed=$false
        while ($i -lt $keys.Count) { $key=$keys[$i++]; if ($PSBoundParameters.ContainsKey($key)) { $entry[$fields[$key]]=$PSBoundParameters[$key]; $changed=$true } }
        if (-not $changed) { throw 'SetCondition requires a changed field.' }
    }
}
Write-StateRegistry $registryPath $table
