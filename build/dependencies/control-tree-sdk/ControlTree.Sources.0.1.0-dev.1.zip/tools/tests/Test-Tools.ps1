#Requires -Version 7.4
[CmdletBinding()]
param([string]$ArtifactRoot=(Join-Path $PSScriptRoot '../../.local/tools-tests'))
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$tools=Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $tools 'StateItemRegistry.psm1') -Force
$ArtifactRoot=[IO.Path]::GetFullPath($ArtifactRoot); $null=[IO.Directory]::CreateDirectory($ArtifactRoot)
$results=[Collections.Generic.List[object]]::new()
function Save-Text([string]$Path,[string]$Text) { $null=[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Path)); [IO.File]::WriteAllText($Path,($Text -replace "`r`n","`n"),[Text.UTF8Encoding]::new($false)) }
function Save-Json([string]$Path,$Value) { Save-Text $Path ((ConvertTo-Json -InputObject $Value -Depth 64)+"`n") }
function Assert-True([bool]$Value,[string]$Message) { if (-not $Value) { throw $Message } }
function Expect-Failure([scriptblock]$Body,[string]$Pattern) {
    $failure=$null
    try { $null=& $Body } catch { $failure=$_.Exception.Message }
    if (-not $failure -or $failure -notmatch $Pattern) { throw "Expected failure '$Pattern', got '$failure'." }
}
function Test([string]$Name,[scriptblock]$Body) {
    try { & $Body; $results.Add([ordered]@{name=$Name;passed=$true}); "PASS $Name" }
    catch { $results.Add([ordered]@{name=$Name;passed=$false;error=$_.Exception.Message}); "FAIL ${Name}: $($_.Exception.Message)" }
}
function Copy-Registry { ConvertFrom-Json -InputObject (ConvertTo-Json -InputObject $script:fixture -Depth 64) -AsHashtable -Depth 64 }
function Invalid-Registry([scriptblock]$Change,[string]$Pattern) { $value=Copy-Registry; & $Change $value; Expect-Failure { Assert-StateRegistry $value } $Pattern }
$fixture=[ordered]@{
    schemaVersion=1
    processes=[ordered]@{
        forge=@{generate=@(@{language='Zig';output='forge.zig'},@{language='CSharp';output='forge.cs';namespace='Independent.Forge'});export=@{directory='forge-build';step='declaration-export';arguments=@('-Dstate-names=true')}}
        'logic-engine'=@{generate=@(@{language='Zig';output='logic.zig'},@{language='CSharp';output='logic.cs';namespace='Independent.Logic'})}
    }
    types=@{Flag=@{valueType='bool'};Document=@{valueType='host'}}
    entries=@(
        [ordered]@{uid=1;kind='block';process='forge';name='Program';comment='Root.'}
        [ordered]@{uid=2;kind='block';process='forge';name='Launcher';comment='Starts child process.'}
        [ordered]@{uid=3;kind='item';process='forge';name='Permission';comment='private-comment-marker';storage='reference';type='Flag';owner=@{component='origin'};perBlock=$false;trigger='event';changeEvent='permission.changed'}
        [ordered]@{uid=4;kind='condition';process='forge';name='Run';comment='Decides launcher.';node=1;perBlock=$false;items=@(@{item=3});conditions=@();children=@();decides=2}
        [ordered]@{uid=5;kind='block';process='logic-engine';name='Program';comment='Other root.'}
        [ordered]@{uid=6;kind='block';process='logic-engine';name='class';comment='Other execution flow.'}
        [ordered]@{uid=7;kind='condition';process='logic-engine';name='Run';comment='Same name in other process.';node=5;perBlock=$false;items=@();conditions=@();children=@();decides=6}
    )
}
$registryPath=Join-Path $ArtifactRoot 'registry.json'; Write-StateRegistry $registryPath $fixture
$manage=Join-Path $tools 'Manage-StateItems.ps1'; $generate=Join-Path $tools 'Generate-StateItems.ps1'; $export=Join-Path $tools 'Export-ControlTree.ps1'
Test 'smallest-hole allocation, rename identity, remove without renumbering' {
    $path=Join-Path $ArtifactRoot 'mutations.json'; Write-StateRegistry $path (Copy-Registry)
    $uid=& $manage -Registry $path -Action Add -Kind block -Process forge -Name Spare -Comment 'Unused flow.'
    Assert-True ($uid -eq 8) 'Append should allocate UID 8.'
    & $manage -Registry $path -Action Remove -Uids 8
    $uid=& $manage -Registry $path -Action Add -Kind block -Process forge -Name Replacement -Comment 'Reused hole.'
    Assert-True ($uid -eq 8) 'Removal should leave hole 8.'
    & $manage -Registry $path -Action Rename -Uid 8 -Name Renamed -Comment 'Identity unchanged.'
    $resolved=& $manage -Registry $path -Action Resolve -Uid 8 | ConvertFrom-Json
    Assert-True ($resolved.uid -eq 8 -and $resolved.name -ceq 'Renamed') 'Rename changed identity.'
    & $manage -Registry $path -Action Remove -Uids 7
    $uid=& $manage -Registry $path -Action Add -Kind block -Process forge -Name MiddleHole -Comment 'Smallest internal hole.'
    Assert-True ($uid -eq 7) 'Must fill internal hole before appending.'
    $current=Read-StateRegistry -Path $path
    Assert-True ($current.entries[-1].uid -eq 8 -and $current.entries[-1].name -ceq 'Renamed') 'Removal renumbered a surviving entry.'
}
Test 'failed mutations preserve exact registry bytes' {
    $path=Join-Path $ArtifactRoot 'atomic.json'; Write-StateRegistry $path (Copy-Registry)
    $before=[IO.File]::ReadAllBytes($path)
    Expect-Failure { & $manage -Registry $path -Action Rename -Uid 2 -Name Program } 'Duplicate name'
    Expect-Failure { & $manage -Registry $path -Action Remove -Uids 3 } 'unknown item'
    Expect-Failure { & $manage -Registry $path -Action Move -Uids 3 -Process 'logic-engine' } 'unknown item'
    Assert-True ([Convert]::ToBase64String($before) -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes($path))) 'Failed mutation changed file.'
}
Test 'SetItem and SetCondition keep UID, owner and declared dependencies' {
    $path=Join-Path $ArtifactRoot 'updates.json'; Write-StateRegistry $path (Copy-Registry)
    $null=& $manage -Registry $path -Action SetItem -Uid 3 -OwnerBlock 2 -ChangeEvent 'launcher.changed'
    & $manage -Registry $path -Action SetCondition -Uid 4 -Children @(2) -Comment 'Reads direct child.'
    $current=Read-StateRegistry -Path $path
    Assert-True ($current.entries[2].owner.block -eq 2 -and $current.entries[3].children[0] -eq 2) 'Set operations lost updated dependencies.'
}
Test 'duplicate UID rejected' { Invalid-Registry {param($v) $v.entries[1].uid=1} 'Duplicate UID' }
Test 'process-wide duplicate name rejected' { Invalid-Registry {param($v) $v.entries[1].name='Program'} 'Duplicate name' }
Test 'undeclared process and type rejected' {
    Invalid-Registry {param($v) $v.entries[1].process='invented'} 'Unknown process'
    Invalid-Registry {param($v) $v.entries[2].type='invented'} 'Unknown type'
}
Test 'unknown and cross-process owners rejected' {
    Invalid-Registry {param($v) $v.entries[2].owner=@{block=900}} 'unknown block'
    Invalid-Registry {param($v) $v.entries[2].owner=@{block=6}} 'unknown block'
}
Test 'unregistered reads and host-only condition reads rejected' {
    Invalid-Registry {param($v) $v.entries[3].items=@(@{item=999})} 'unknown item'
    Invalid-Registry {param($v) $v.entries[2].type='Document'} 'cannot read host item'
}
Test 'condition cycles and cross-node lower conditions rejected' {
    Invalid-Registry {param($v) $v.entries[3].conditions=@(4)} 'Condition cycle'
    $value=Copy-Registry
    $value.entries+=@{uid=8;kind='condition';process='forge';name='Lower';comment='Other node.';perBlock=$false;node=2;items=@();conditions=@();children=@()}
    $value.entries[3].conditions=@(8)
    Expect-Failure { Assert-StateRegistry $value } 'same node'
}
Test 'per-block selectors validated' {
    Invalid-Registry {param($v) $v.entries[3].items=@(@{item=3;block=2})} 'Only per-block'
    Invalid-Registry {param($v) $v.entries[2].perBlock=$true} 'requires a block selector'
    $value=Copy-Registry; $value.entries[2].perBlock=$true; $value.entries[3].items=@(@{item=3;block=2}); Assert-StateRegistry $value
}
Test 'strict byte encoding and duplicate JSON keys rejected' {
    $bytes=[IO.File]::ReadAllBytes($registryPath)
    Expect-Failure { Read-StateRegistry -Bytes ([byte[]](@(239,187,191)+$bytes)) } 'BOM'
    Expect-Failure { Read-StateRegistry -Bytes ([Text.Encoding]::UTF8.GetBytes(([Text.Encoding]::UTF8.GetString($bytes) -replace "`n","`r`n"))) } 'CR'
    Expect-Failure { Read-StateRegistry -Bytes ([Text.Encoding]::UTF8.GetBytes('{"schemaVersion":1,"schemaVersion":1}')) } 'Duplicate JSON field'
}
Test 'registry byte limit rejects smaller budgets and permits exact file and byte-array budgets' {
    $bytes=[IO.File]::ReadAllBytes($registryPath); $small=$bytes.Length-1
    Expect-Failure { Read-StateRegistry -Path $registryPath -MaxBytes $small } 'Registry exceeds'
    Expect-Failure { Read-StateRegistry -Bytes $bytes -MaxBytes $small } 'Registry exceeds'
    $fromFile=Read-StateRegistry -Path $registryPath -MaxBytes $bytes.Length
    $fromBytes=Read-StateRegistry -Bytes $bytes -MaxBytes $bytes.Length
    Assert-True ($fromFile.entries.Count -eq 7 -and $fromBytes.entries.Count -eq 7) 'Raising registry budget did not permit the same valid registry.'
    Expect-Failure { Read-StateRegistry -Path $registryPath -MaxBytes 0 } 'MaxBytes'
}
Test 'blob SHA1 matches independent header-plus-content digest' {
    $bytes=[IO.File]::ReadAllBytes($registryPath); $header=[Text.Encoding]::UTF8.GetBytes("blob $($bytes.Length)`0")
    $combined=[byte[]]::new($header.Length+$bytes.Length); [Array]::Copy($header,0,$combined,0,$header.Length); [Array]::Copy($bytes,0,$combined,$header.Length,$bytes.Length)
    $expected=[Convert]::ToHexString([Security.Cryptography.SHA1]::HashData($combined)).ToLowerInvariant()
    Assert-True ((Get-StateRegistryVersion $bytes) -ceq $expected) 'Wrong blob digest.'
    Assert-True ((Get-StateRegistryVersion ([byte[]]@())) -ceq 'e69de29bb2d1d6434b8b29ae775ad8c2e48c5391') 'Empty blob known vector failed.'
}
Test 'historical export/resolve retains identity after UID reuse, rejects tampering' {
    $path=Join-Path $ArtifactRoot 'historical.json'; Write-StateRegistry $path (Copy-Registry)
    $directory=Join-Path $ArtifactRoot 'tables'; $versionId=& $manage -Registry $path -Action Export -Destination $directory
    & $manage -Registry $path -Action Remove -Uids 7
    $null=& $manage -Registry $path -Action Add -Kind block -Process forge -Name Reused -Comment 'New identity.'
    $old=& $manage -Registry $path -Action Resolve -Uid 7 -Version $versionId -TableDirectory $directory | ConvertFrom-Json
    $new=& $manage -Registry $path -Action Resolve -Uid 7 | ConvertFrom-Json
    Assert-True ($old.name -ceq 'Run' -and $new.name -ceq 'Reused') 'Historical identity did not survive UID reuse.'
    $published=Join-Path $directory "$versionId.json"; $data=[IO.File]::ReadAllBytes($published); $changed=[byte[]]::new($data.Length+1); [Array]::Copy($data,$changed,$data.Length); $changed[-1]=10; [IO.File]::WriteAllBytes($published,$changed)
    Expect-Failure { & $manage -Registry $path -Action Resolve -Uid 7 -Version $versionId -TableDirectory $directory } 'hash mismatch'
    [IO.File]::WriteAllBytes($published,$data)
}
Test 'generic two-process Zig/CSharp generation, deterministic bytes and keyword identifiers' {
    & $generate -Registry $registryPath
    $zig=[IO.File]::ReadAllText((Join-Path $ArtifactRoot 'logic.zig')); $cs=[IO.File]::ReadAllText((Join-Path $ArtifactRoot 'logic.cs'))
    Assert-True ($zig.Contains('@import("control_tree")') -and $zig.Contains('.process = "logic-engine"') -and $zig.Contains('pub const @"class": u32 = 6')) 'Generic Zig declaration lost process/keyword.'
    Assert-True ($cs.Contains('namespace @Independent.@Logic;') -and $cs.Contains('uint @class = 6u') -and -not $cs.Contains('ResourceManager')) 'CSharp output depends on product implementation.'
    $before=[IO.File]::ReadAllBytes((Join-Path $ArtifactRoot 'forge.zig')); & $generate -Registry $registryPath
    Assert-True ([Convert]::ToBase64String($before) -ceq [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $ArtifactRoot 'forge.zig')))) 'Same bytes produced unstable generation.'
    Assert-True (-not ($before -contains [byte]13) -and $before[0] -ne 239) 'Generated bytes are not LF/no-BOM.'
}
Test 'one CSharp source compiles production without name table and development with comments' {
    $source=[IO.File]::ReadAllText((Join-Path $ArtifactRoot 'forge.cs'))
    $releasePath=Join-Path $ArtifactRoot ('release-'+[guid]::NewGuid().ToString('N')+'.dll')
    $debugPath=Join-Path $ArtifactRoot ('development-'+[guid]::NewGuid().ToString('N')+'.dll')
    Add-Type -TypeDefinition $source -OutputAssembly $releasePath
    Add-Type -TypeDefinition $source -CompilerOptions '/define:CONTROL_TREE_STATE_NAMES' -OutputAssembly $debugPath
    $release=[Reflection.Assembly]::LoadFile($releasePath); $debug=[Reflection.Assembly]::LoadFile($debugPath)
    Assert-True ($null -eq $release.GetType('Independent.Forge.StateNames') -and $null -ne $debug.GetType('Independent.Forge.StateNames')) 'Compile flag failed to remove name table.'
    $releaseText=[Text.Encoding]::Unicode.GetString([IO.File]::ReadAllBytes($releasePath)); $debugText=[Text.Encoding]::Unicode.GetString([IO.File]::ReadAllBytes($debugPath))
    Assert-True (-not $releaseText.Contains('private-comment-marker') -and $debugText.Contains('private-comment-marker')) 'Production retains comment string or development lost it.'
}

function Declaration([string]$ProfileName,[string]$Launch=$null) { @{profile=$ProfileName;launchesProcess=$(if ($Launch) { $Launch } else { $null });decidingCondition=@{uid=4;name='Run'}} }
function Read-SourceFixture([string]$Path) { ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($Path)) -AsHashtable -Depth 64 }
$forge=@{schemaVersion=1;process='forge';registryVersion='fixture-version';program=1;profiles=@('full','quiet');conditions=@();blocks=@(
    @{uid=1;name='Program';parent=$null;declarations=@()}
    @{uid=2;name='Launcher';parent=1;declarations=@((Declaration full 'logic-engine'),(Declaration quiet))}
    @{uid=8;name='Extra';parent=2;declarations=@((Declaration full))}
)}
$logic=@{schemaVersion=1;process='logic-engine';registryVersion='other-version';program=5;profiles=@('full','quiet');conditions=@();blocks=@(
    @{uid=5;name='Program';parent=$null;declarations=@()}
    @{uid=6;name='class';parent=5;declarations=@((Declaration full),(Declaration quiet))}
)}
$forgePath=Join-Path $ArtifactRoot 'forge-tree.json'; $logicPath=Join-Path $ArtifactRoot 'logic-tree.json'; Save-Json $forgePath $forge; Save-Json $logicPath $logic
Test 'stitches launched process, preserves metadata and exports arbitrary subtree' {
    $tree=& $export -TreeJson @($forgePath,$logicPath) -Format json | ConvertFrom-Json
    $child=$null; $i=0
    while ($i -lt $tree.blocks.Count) { $block=$tree.blocks[$i++]; if ($block.id -ceq 'logic-engine:class') { $child=$block } }
    Assert-True ($child.parent -ceq 'forge:Launcher' -and $tree.processes[0].registryVersion -ceq 'fixture-version') 'Cross-process stitch or version metadata lost.'
    $subtree=& $export -TreeJson @($forgePath,$logicPath) -From 'forge:Launcher' -Format json | ConvertFrom-Json
    Assert-True ($subtree.blocks.Count -eq 3 -and $null -eq $subtree.blocks[0].parent) 'Arbitrary subtree has wrong root/count.'
    $text=@(& $export -TreeJson @($forgePath,$logicPath) -From 'logic-engine:6')
    Assert-True ($text.Count -eq 1 -and $text[0] -match '^logic-engine:class') 'UID subtree selector failed.'
}
Test 'profile excludes launched branch when launcher does not launch it in profile' {
    $quiet=& $export -TreeJson @($forgePath,$logicPath) -Profile quiet -Format json | ConvertFrom-Json
    Assert-True ($quiet.blocks.Count -eq 2 -and $quiet.blocks[-1].id -ceq 'forge:Launcher') 'Profile floated child process to root.'
    Expect-Failure { & $export -TreeJson @($forgePath,$logicPath) -Profile invented } 'Unknown profile'
}
Test 'text target comparison reports no diff and concrete missing/extra/moved blocks' {
    $target=Join-Path $ArtifactRoot 'target.md'; $text=@(& $export -TreeJson @($forgePath,$logicPath))
    Save-Text $target ("# Target`n`n"+'```control-tree'+"`n"+($text -join "`n")+"`n"+'```'+"`n")
    $diff=& $export -TreeJson @($forgePath,$logicPath) -CompareWith $target -Format json | ConvertFrom-Json
    Assert-True ($diff.missingInCode.Count -eq 0 -and $diff.extraInCode.Count -eq 0 -and $diff.parentDiffers.Count -eq 0) 'Own text export does not compare equal.'
    Save-Text $target ('```control-tree'+"`nProgram`n├─ forge:Launcher`n├─ logic-engine:class`n└─ Missing`n"+'```'+"`n")
    $diff=& $export -TreeJson @($forgePath,$logicPath) -CompareWith $target -Format json | ConvertFrom-Json
    Assert-True ($diff.missingInCode -contains 'Missing' -and $diff.extraInCode -contains 'forge:Extra' -and $diff.parentDiffers[0].block -ceq 'logic-engine:class') 'Comparison failed to identify changes.'
}
Test 'unknown launch, double owner, local cycle and cross-process cycle rejected' {
    $bad=Read-SourceFixture $forgePath
    $bad.blocks[1].declarations[0].launchesProcess='missing'; $badPath=Join-Path $ArtifactRoot 'bad-tree.json'; Save-Json $badPath $bad
    Expect-Failure { & $export -TreeJson @($badPath,$logicPath) } 'Unknown launched process'
    $bad=Read-SourceFixture $forgePath; $bad.blocks[2].declarations[0].launchesProcess='logic-engine'; Save-Json $badPath $bad
    Expect-Failure { & $export -TreeJson @($badPath,$logicPath) } 'launched twice'
    $bad=Read-SourceFixture $forgePath; $bad.blocks[1].parent=8; Save-Json $badPath $bad
    Expect-Failure { & $export -TreeJson @($badPath,$logicPath) -Profile quiet } 'cycle'
    $badLogic=Read-SourceFixture $logicPath; $badLogic.blocks[1].declarations[0].launchesProcess='forge'; Save-Json $badPath $badLogic
    Expect-Failure { & $export -TreeJson @($forgePath,$badPath) } 'cycle'
}
Test 'invalid unknown parent, ambiguous selector and bounded input fail clearly' {
    $bad=Read-SourceFixture $forgePath; $bad.blocks[2].parent=999; $badPath=Join-Path $ArtifactRoot 'bad-parent.json'; Save-Json $badPath $bad
    Expect-Failure { & $export -TreeJson @($badPath,$logicPath) } 'Unknown parent'
    Expect-Failure { & $export -TreeJson @($forgePath,$logicPath) -From absent } 'exactly one'
    Expect-Failure { & $export -TreeJson @($forgePath,$logicPath) -MaxNodes 2 } 'Node limit'
}
Test 'export byte budget rejects smaller limits and permits exact fixture sizes' {
    $bytes=[Math]::Max((Get-Item -LiteralPath $forgePath).Length,(Get-Item -LiteralPath $logicPath).Length)
    Expect-Failure { & $export -TreeJson @($forgePath,$logicPath) -MaxInputBytes 1 } 'at most 1 bytes'
    $tree=& $export -TreeJson @($forgePath,$logicPath) -MaxInputBytes $bytes -Format json | ConvertFrom-Json
    Assert-True ($tree.blocks.Count -eq 4) 'Raising exported-input budget did not permit valid fixtures.'
    Expect-Failure { & $export -TreeJson @($forgePath,$logicPath) -MaxInputBytes 0 } 'MaxInputBytes'
}
Test 'export process-file budget rejects excess files and permits raised limits' {
    Expect-Failure { & $export -TreeJson @($forgePath,$logicPath) -MaxProcessFiles 1 } 'Provide 1\.\.1 TreeJson files'
    $tree=& $export -TreeJson @($forgePath,$logicPath) -MaxProcessFiles 2 -Format json | ConvertFrom-Json
    Assert-True ($tree.processes.Count -eq 2 -and $tree.blocks.Count -eq 4) 'Raising process-file budget did not permit both sources.'
    Expect-Failure { & $export -TreeJson @($forgePath,$logicPath) -MaxProcessFiles 0 } 'MaxProcessFiles'
}
Test 'automatic export obtains generic configuration and invokes JobQueue with one build job' {
    $autoRegistry=Join-Path $ArtifactRoot 'auto-registry.json'; $value=Copy-Registry
    $value.processes.Remove('logic-engine'); $value.entries=@($value.entries[0..3]); Write-StateRegistry $autoRegistry $value
    $source=Read-SourceFixture $forgePath; $source.blocks[1].declarations[0].launchesProcess=$null
    $sourcePath=Join-Path $ArtifactRoot 'auto-tree.json'; Save-Json $sourcePath $source
    $queue=Join-Path $ArtifactRoot 'Mock-JobQueue.ps1'
    Save-Text $queue @'
param([string]$Action,[string]$Label,[string]$FilePath,[string]$WorkingDirectory,[int]$TimeoutMinutes,[int]$MemoryLimitGiB,[string[]]$ArgumentList)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$record=[ordered]@{action=$Action;filePath=$FilePath;directory=$WorkingDirectory;arguments=$ArgumentList;globalCache=$env:ZIG_GLOBAL_CACHE_DIR;memoryLimitGiB=$MemoryLimitGiB}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'queue-call.json'),((ConvertTo-Json $record -Depth 8) -replace "`r`n","`n"),[Text.UTF8Encoding]::new($false))
[ordered]@{log=(Join-Path $PSScriptRoot 'auto-tree.json');errorLog=(Join-Path $PSScriptRoot 'unused-error.log')} | ConvertTo-Json -Compress
'@
    $hostExe=Join-Path $PSHOME $(if ($IsWindows) { 'pwsh.exe' } else { 'pwsh' })
    $tree=& $export -Registry $autoRegistry -Zig $hostExe -JobQueue $queue -WorkRoot (Join-Path $ArtifactRoot 'queue-work') -Format json | ConvertFrom-Json
    $call=Read-SourceFixture (Join-Path $ArtifactRoot 'queue-call.json')
    Assert-True ($call.arguments[0] -ceq 'build' -and $call.arguments[1] -ceq 'declaration-export' -and $call.arguments -contains '-j1' -and $call.arguments -contains '-Dstate-names=true' -and $call.directory -ceq (Join-Path $ArtifactRoot 'forge-build') -and $tree.blocks.Count -eq 3) 'Automatic export did not use declared process/queue/single-job settings.'
    Assert-True ($call.arguments -contains '--cache-dir' -and $call.arguments -notcontains '--global-cache-dir' -and $call.globalCache.StartsWith((Join-Path $ArtifactRoot 'queue-work')) -and (Split-Path -Leaf $call.globalCache) -ceq 'global-cache') 'Child did not inherit the isolated global cache environment.'
    $null=& $export -Registry $autoRegistry -Process forge -ExportDirectory $ArtifactRoot -ExportStep alternate -ExportArguments @('-Dcustom=true') -Zig $hostExe -JobQueue $queue -WorkRoot (Join-Path $ArtifactRoot 'queue-work') -Format json
    $call=Read-SourceFixture (Join-Path $ArtifactRoot 'queue-call.json')
    Assert-True ($call.arguments[1] -ceq 'alternate' -and $call.arguments -contains '-Dcustom=true' -and $call.directory -ceq $ArtifactRoot) 'Explicit export overrides were ignored.'
    Expect-Failure { & $export -Registry $autoRegistry -Process forge -ExportArguments @('-j8') -Zig $hostExe -JobQueue $queue } 'cannot override'
    Expect-Failure { & $export -Registry $autoRegistry -Process forge -ExportArguments @('--global-cache=elsewhere') -Zig $hostExe -JobQueue $queue } 'cannot override'
    Invalid-Registry {param($v) $v.processes.forge.export.arguments=@('--global-cache-dir','elsewhere')} 'cannot override'
    Invalid-Registry {param($v) $v.processes.forge.export.arguments=@('--global-cache=elsewhere')} 'cannot override'
}
Test 'automatic export restores global-cache environment after success and child failure' {
    $autoRegistry=Join-Path $ArtifactRoot 'auto-registry.json'; $queue=Join-Path $ArtifactRoot 'Mock-JobQueue.ps1'
    $hostExe=Join-Path $PSHOME $(if ($IsWindows) { 'pwsh.exe' } else { 'pwsh' })
    $hadOriginal=Test-Path -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR; $original=$env:ZIG_GLOBAL_CACHE_DIR
    try {
        $sentinel=Join-Path $ArtifactRoot 'caller-global-cache'; $env:ZIG_GLOBAL_CACHE_DIR=$sentinel
        $null=& $export -Registry $autoRegistry -Zig $hostExe -JobQueue $queue -WorkRoot (Join-Path $ArtifactRoot 'queue-work') -Format json
        Assert-True ($env:ZIG_GLOBAL_CACHE_DIR -ceq $sentinel) 'Successful export changed an existing environment value.'
        Remove-Item -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR
        $null=& $export -Registry $autoRegistry -Zig $hostExe -JobQueue $queue -WorkRoot (Join-Path $ArtifactRoot 'queue-work') -Format json
        Assert-True (-not (Test-Path -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR)) 'Successful export left a new environment variable behind.'
        $failingQueue=Join-Path $ArtifactRoot 'Mock-FailingJobQueue.ps1'; Save-Text $failingQueue ([IO.File]::ReadAllText($queue)+"`nexit 9`n")
        $env:ZIG_GLOBAL_CACHE_DIR=$sentinel
        Expect-Failure { & $export -Registry $autoRegistry -Zig $hostExe -JobQueue $failingQueue -WorkRoot (Join-Path $ArtifactRoot 'queue-work') } 'Export failed.*exit [1-9]'
        Assert-True ($env:ZIG_GLOBAL_CACHE_DIR -ceq $sentinel) 'Failed export changed an existing environment value.'
        Remove-Item -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR
        Expect-Failure { & $export -Registry $autoRegistry -Zig $hostExe -JobQueue $failingQueue -WorkRoot (Join-Path $ArtifactRoot 'queue-work') } 'Export failed.*exit [1-9]'
        Assert-True (-not (Test-Path -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR)) 'Failed export left a new environment variable behind.'
    } finally {
        if ($hadOriginal) { $env:ZIG_GLOBAL_CACHE_DIR=$original }
        else { Remove-Item -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR -ErrorAction SilentlyContinue }
    }
}
Test 'explicit scratch directory reuses stable caches without removing existing files' {
    $autoRegistry=Join-Path $ArtifactRoot 'auto-registry.json'; $queue=Join-Path $ArtifactRoot 'Mock-JobQueue.ps1'
    $hostExe=Join-Path $PSHOME $(if ($IsWindows) { 'pwsh.exe' } else { 'pwsh' })
    $scratch=Join-Path $ArtifactRoot 'reusable-scratch'; $null=[IO.Directory]::CreateDirectory($scratch)
    $marker=Join-Path $scratch 'existing-cache-marker'; Save-Text $marker 'preserve existing cache'
    $hadOriginal=Test-Path -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR; $original=$env:ZIG_GLOBAL_CACHE_DIR
    try {
        $sentinel=Join-Path $ArtifactRoot 'scratch-caller-cache'; $env:ZIG_GLOBAL_CACHE_DIR=$sentinel
        $null=& $export -Registry $autoRegistry -Zig $hostExe -JobQueue $queue -ScratchDirectory $scratch -Format json
        $first=Read-SourceFixture (Join-Path $ArtifactRoot 'queue-call.json')
        Assert-True ($first.memoryLimitGiB -eq 6 -and $env:ZIG_GLOBAL_CACHE_DIR -ceq $sentinel) 'Default queue memory or environment restoration changed.'
        $null=& $export -Registry $autoRegistry -Zig $hostExe -JobQueue $queue -ScratchDirectory $scratch -MemoryLimitGiB 7 -Format json
        $second=Read-SourceFixture (Join-Path $ArtifactRoot 'queue-call.json')
        $cacheIndex=[Array]::IndexOf([string[]]$first.arguments,'--cache-dir')
        Assert-True ($cacheIndex -ge 0 -and $first.arguments[$cacheIndex+1] -ceq (Join-Path $scratch 'forge-cache') -and $second.arguments[$cacheIndex+1] -ceq $first.arguments[$cacheIndex+1]) 'Local cache changed across retries.'
        Assert-True ($first.globalCache -ceq (Join-Path $scratch 'global-cache') -and $second.globalCache -ceq $first.globalCache -and $env:ZIG_GLOBAL_CACHE_DIR -ceq $sentinel) 'Global cache changed across retries or escaped to the parent environment.'
        Assert-True ($second.memoryLimitGiB -eq 7 -and [IO.File]::ReadAllText($marker) -ceq 'preserve existing cache') 'Memory override failed or reusable scratch files were removed.'
    } finally {
        if ($hadOriginal) { $env:ZIG_GLOBAL_CACHE_DIR=$original }
        else { Remove-Item -LiteralPath Env:ZIG_GLOBAL_CACHE_DIR -ErrorAction SilentlyContinue }
    }
}
$passed=0; $failed=0; $i=0
while ($i -lt $results.Count) { if ($results[$i++].passed) { $passed++ } else { $failed++ } }
$summary=[ordered]@{passed=$passed;failed=$failed;powershell=$PSVersionTable.PSVersion.ToString();zigExecuted=$false;tests=$results.ToArray()}
Save-Json (Join-Path $ArtifactRoot 'results.json') $summary
"RESULT passed=$passed failed=$failed"
if ($failed -gt 0) { throw "$failed tool behavior test(s) failed; see results.json." }
