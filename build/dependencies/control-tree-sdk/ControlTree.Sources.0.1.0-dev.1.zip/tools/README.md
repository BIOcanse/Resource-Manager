# ControlTree tools

PowerShell 7.4+ is required. All registry and generated text is UTF-8 without BOM,
with LF line endings. UID allocation fills the smallest positive unused number;
removal never renumbers surviving entries. Writers validate before replacing a file.

## Registry schema 1

The top-level object contains `schemaVersion: 1`, `processes`, `types`, and
`entries`. `processes` is an object keyed by arbitrary process identifiers. Each
process declares `generate`, an array of `{ language: "Zig"|"CSharp", output: "..." }`.
Paths are relative to the registry directory. CSharp optionally declares
`namespace` (default `ControlTree.Generated`). Every process must have a Zig
output. Optional `export` declares `{ directory: "...", step: "export-tree",
arguments: [] }`, also relative to the registry. Only Zig build export is supported.
Arguments cannot override the mandatory single-job or cache arguments.

`types` maps project type identifiers to `{ valueType: "bool"|"host" }`. Host
payloads stay with their owner and cannot be read by conditions. These are type
declarations, not a second type authority or host type parser.

Entries retain the source registry contract: shared positive uint32 `uid`,
`kind: block|item|condition`, `process`, process-unique ASCII `name`, and `comment`.
Items add `storage: own|reference`, `type`, exactly one `owner.block` or
`owner.component`, boolean `perBlock`, `trigger: event|poll`, and `changeEvent` or
`pollInterval`, respectively. Conditions add boolean `perBlock`, arrays `items`
(`{item, block?}`), `conditions`, `children`; non-per-block conditions have `node`
and optionally `decides`. Per-block conditions omit node/decides and read items only.
Block owners and all condition references must exist in the same process.
Control-tree parent/child consistency remains the declaration validator's job.

## Commands

`Manage-StateItems.ps1 -Registry registry.json -Action Add|Rename|Remove|Move|SetItem|SetCondition|Resolve|Export`
preserves identities, validates complete mutations, and supports versioned table
export/resolve. Resolve uses `-Version <blob-sha1> -TableDirectory <directory>` and
never invokes git. Blob IDs hash the exact `blob <byte-count>\0<file-bytes>` bytes.

`Generate-StateItems.ps1 -Registry registry.json` generates every declared output.
Optional `-Process`, `-Language`, and `-Output` select/override one output; an
explicit output requires one process and one language. Zig always imports
`control_tree` and `build_options.state_names`. Wire the same build-options module
into each generated module; set `state_names=true` for development exports and
false for production. CSharp uses `CONTROL_TREE_STATE_NAMES` for the same purpose.
Generated CSharp consists of integer constants and self-contained declaration
records; it has no dependency on a product namespace or SDK host wrapper.

`Export-ControlTree.ps1 -TreeJson <per-process.json[]> -From Program -Profile <name> -Format text|json`
stitches declarations through `launchesProcess`, supports arbitrary subtree roots,
and compares with a `control-tree` fenced document using `-CompareWith`.
Without TreeJson, provide `-Registry`, `-Zig`, `-JobQueue`, and optionally `-WorkRoot`.
Automatic export normally creates a random scratch directory under WorkRoot.
Set `-ScratchDirectory <path>` to reuse an existing directory and its per-process
local caches plus shared global cache across retries. The directory is created
if absent; existing files are preserved and nothing is deleted. JobQueue's
`-MemoryLimitGiB` default is 6 GiB, and the caller may override it; the SDK root
configurer exceeded the previous 4 GiB cap in a real integration job.
The registry export entries choose process directories/steps; overrides
`-ExportDirectory`, `-ExportStep`, `-ExportArguments` apply to a single `-Process`.
All automatic exports use JobQueue and `zig build <step> -j1`, never product code.
The build arguments include `--cache-dir`; the global cache is passed to the
child through `ZIG_GLOBAL_CACHE_DIR=<scratch>/global-cache`, matching Zig 0.17
maker builds. The previous environment value is restored in `finally`, or the
variable is removed if originally absent. Extra export arguments cannot override
job count, local cache, or either `--global-cache` routing form.
`-MaxInputBytes` limits each exported JSON, comparison document, or JobQueue log
read (default 64 MiB, range 1..2147483647 bytes). `-MaxProcessFiles` limits the
TreeJson file count (default 64, range 1..65536). Registry consumers can override
the module's `Read-StateRegistry -MaxBytes` limit (default 64 MiB, range
1..2147483647 bytes) for either file or byte-array input. Schema structure limits
remain unchanged.

`tests/Test-Tools.ps1` runs behavior tests without Zig. It writes its bounded scratch
fixtures and a JSON result/log under `.local/tools-tests` by default. These files
can be overwritten on the next run. No recursive filesystem deletion is used.
