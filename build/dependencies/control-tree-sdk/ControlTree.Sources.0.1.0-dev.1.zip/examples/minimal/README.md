# Minimal consumer

The tree is `Program -> Branch -> Worker`. `registry.json` is maintained by the
SDK registry tool; `generated/state_items.zig` is its generated declaration module.

```control-tree
Program
└─ minimal:Branch
   └─ minimal:Worker
```

The host owns one reference boolean, `HostStartPermitted`. Both decision nodes
read it and treat every missing-value reason as false. `IsShuttingDown` is an own
boolean used by the controller shutdown path. All UIDs belong to this consumer.

`src/tree.zig` supplies the topology, conditions, explicit example parameters and
concrete Controller type. `src/library.zig` maps configuration 1 to that Controller
with only id and Controller fields; the exporter reads its runnable_blocks metadata.
The host separately declares its actual block registrations in Config. The library exports
the generic C symbols. `src/export_tree.zig` supplies declarations to the SDK's
development exporter, without constructing a controller.

The root build uses `abi/build-support.zig` to build the library and the declaration
export executable. The registry module imports `control_tree` and
`build_options.state_names`; with names disabled, the same generated file omits
names and comments from runtime data.

Example capacity defaults are declared once in `abi/build-support.zig` and are
overridable with `-Dexample-workers`, `-Dexample-history-capacity`,
`-Dexample-completion-capacity`, `-Dexample-reader-capacity`,
`-Dexample-reader-bytes`, `-Dexample-worker-arena-bytes` and
`-Dexample-reason-text-capacity`. Both entry paths receive the same values.

`tests/scenarios.zig` loads the built dynamic library with the Windows loader and
checks every public symbol. Each scenario then runs through both the DLL C API
and direct Zig Controller calls. Host callbacks append to a bounded queue; the
test explicitly executes queued start and stop work. It checks top-down starts,
bottom-up stops, revocation before parent stop, spontaneous return followed by
descendant drain before restart, late running reports, fresh run numbers and old
return rejection. The event trace and stable snapshot fields, including the full
transition trace, must match. Decision histories may differ with worker scheduling.

The test host has no actual application tasks. Production hosts must also ensure
that a reported return means all execution and asynchronous cleanup for that run
have ended; runtime scopes for language wrappers are a later SDK delivery.
