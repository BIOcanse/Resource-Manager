//! The same script drives a direct Zig Controller and symbols loaded from the
//! consumer DLL. Host callbacks only record observations; the script executes
//! the queued host work explicitly, including delayed start/return reports.
const std = @import("std");
const control = @import("control_tree");
const abi = @import("control_tree_abi");
const minimal = @import("minimal");
const runtime = @import("runtime_options");
const B = minimal.declarations.BlockUids;
const I = minimal.declarations.ItemUids;
const Signatures = abi.Exporter(.{
    .{ .id = minimal.options.configuration, .Controller = minimal.Engine },
});
const why: control.Reason = .{ .kind = 1, .owner = "minimal-test", .cause = "scenario", .plan_version = 1 };
const reason_view = abi.ReasonView.fromReason(why);
const eq = std.testing.expectEqual;

// The current controller's blocking synchronization is Windows-specific. Use
// the native loader here: Zig 0.17's std.DynLib has no Windows backend.
extern "kernel32" fn LoadLibraryW([*:0]const u16) callconv(.winapi) ?*anyopaque;
extern "kernel32" fn GetProcAddress(*anyopaque, [*:0]const u8) callconv(.winapi) ?*anyopaque;
extern "kernel32" fn FreeLibrary(*anyopaque) callconv(.winapi) c_int;
const Library = struct {
    handle: *anyopaque,
    fn open() !Library {
        const path = try std.unicode.utf8ToUtf16LeAllocZ(std.testing.allocator, runtime.library_path);
        defer std.testing.allocator.free(path);
        return .{ .handle = LoadLibraryW(path.ptr) orelse return error.LoadLibraryFailed };
    }
    fn close(self: Library) void {
        std.debug.assert(FreeLibrary(self.handle) != 0);
    }
    fn get(self: Library, comptime name: [:0]const u8) !@TypeOf(&@field(Signatures, name)) {
        return @ptrCast(GetProcAddress(self.handle, name.ptr) orelse return error.MissingSymbol);
    }
};

const Api = struct {
    create: @TypeOf(&Signatures.control_tree_create),
    activate: @TypeOf(&Signatures.control_tree_activate),
    destroy: @TypeOf(&Signatures.control_tree_destroy),
    claim: @TypeOf(&Signatures.control_tree_claim_cell),
    publish: @TypeOf(&Signatures.control_tree_publish),
    read_state: @TypeOf(&Signatures.control_tree_read_state),
    running: @TypeOf(&Signatures.control_tree_run_running),
    returned: @TypeOf(&Signatures.control_tree_run_returned),
    shutdown: @TypeOf(&Signatures.control_tree_shutdown),
    snapshot: @TypeOf(&Signatures.control_tree_snapshot),
    fn load(lib: Library) !Api {
        // Check all advertised symbols, including operations not used by this script.
        inline for (abi.symbol_names) |name| _ = try lib.get(name);
        const version = try lib.get("control_tree_abi_version");
        try eq(abi.abi_version, version());
        return .{
            .create = try lib.get("control_tree_create"),
            .activate = try lib.get("control_tree_activate"),
            .destroy = try lib.get("control_tree_destroy"),
            .claim = try lib.get("control_tree_claim_cell"),
            .publish = try lib.get("control_tree_publish"),
            .read_state = try lib.get("control_tree_read_state"),
            .running = try lib.get("control_tree_run_running"),
            .returned = try lib.get("control_tree_run_returned"),
            .shutdown = try lib.get("control_tree_shutdown"),
            .snapshot = try lib.get("control_tree_snapshot"),
        };
    }
};

fn cConfig() abi.Config {
    const o = minimal.options;
    return .{
        .struct_size = @sizeOf(abi.Config),
        .configuration = o.configuration,
        .worker_count = o.worker_count,
        .history_capacity = o.history_capacity,
        .completion_capacity = o.completion_capacity,
        .reader_capacity = o.reader_capacity,
        .reader_bytes = o.reader_bytes,
        .worker_arena_bytes = o.worker_arena_bytes,
        .reason_text_capacity = o.reason_text_capacity,
        .shutdown_item_uid = I.IsShuttingDown,
        .host_blocks = &minimal.host_block_uids,
        .host_block_count = minimal.host_block_uids.len,
    };
}

const Driver = union(enum) {
    direct: *minimal.Engine,
    dynamic: struct { api: *const Api, handle: ?*anyopaque },
    fn create(api: ?*const Api, host: *Host) !Driver {
        if (api) |c| {
            const cfg = cConfig();
            const cb = host.cCallbacks();
            var handle: ?*anyopaque = null;
            try eq(abi.code(.ok), c.create(&cfg, &cb, &handle));
            return .{ .dynamic = .{ .api = c, .handle = handle } };
        }
        return .{ .direct = try minimal.Engine.create(std.testing.allocator, minimal.config(), host.callbacks()) };
    }
    fn activate(self: Driver) !void {
        switch (self) {
            .direct => |engine| engine.activate(),
            .dynamic => |c| try eq(abi.code(.ok), c.api.activate(c.handle)),
        }
    }
    fn destroy(self: Driver) !void {
        switch (self) {
            .direct => |engine| try engine.destroy(),
            .dynamic => |c| try eq(abi.code(.ok), c.api.destroy(c.handle)),
        }
    }
    fn claim(self: Driver) !control.state.Claim {
        const key = abi.ItemKeyView{ .item = I.HostStartPermitted, .block = 0 };
        return switch (self) {
            .direct => |engine| try engine.claimCell(key.toKey()),
            .dynamic => |c| blk: {
                var claim_value: ?*anyopaque = null;
                try eq(abi.code(.ok), c.api.claim(c.handle, &key, &claim_value));
                break :blk @ptrCast(claim_value.?);
            },
        };
    }
    fn duplicateClaimCode(self: Driver) i32 {
        return switch (self) {
            .direct => |engine| blk: {
                _ = engine.claimCell(.{ .item = I.HostStartPermitted }) catch |err| break :blk abi.codeFor(err);
                break :blk abi.code(.ok);
            },
            .dynamic => |c| blk: {
                const key = abi.ItemKeyView{ .item = I.HostStartPermitted, .block = 0 };
                var claim_value: ?*anyopaque = null;
                break :blk c.api.claim(c.handle, &key, &claim_value);
            },
        };
    }
    fn unknownBlockCode(self: Driver) i32 {
        return switch (self) {
            .direct => |engine| blk: {
                _ = engine.readState(999) catch |err| break :blk abi.codeFor(err);
                break :blk abi.code(.ok);
            },
            .dynamic => |c| blk: {
                var value: u32 = 99;
                break :blk c.api.read_state(c.handle, 999, &value);
            },
        };
    }
    fn prematureDestroyCode(self: Driver) i32 {
        return switch (self) {
            .direct => |engine| blk: {
                engine.destroy() catch |err| break :blk abi.codeFor(err);
                break :blk abi.code(.ok);
            },
            .dynamic => |c| c.api.destroy(c.handle),
        };
    }
    fn publish(self: Driver, claim_value: control.state.Claim, value: bool, token: u64) !void {
        switch (self) {
            .direct => |engine| try engine.publish(claim_value, .{ .value = value }, why, if (token == 0) null else token),
            .dynamic => |c| try eq(abi.code(.ok), c.api.publish(c.handle, @ptrCast(claim_value), if (value) 4 else 3, &reason_view, token)),
        }
    }
    fn state(self: Driver, uid: u32) !control.BlockState {
        return switch (self) {
            .direct => |engine| try engine.readState(uid),
            .dynamic => |c| blk: {
                var value: u32 = 99;
                try eq(abi.code(.ok), c.api.read_state(c.handle, uid, &value));
                break :blk @fromBackingInt(@intCast(value));
            },
        };
    }
    fn running(self: Driver, uid: u32, run: u64) !void {
        switch (self) {
            .direct => |engine| try engine.reportRunning(uid, run),
            .dynamic => |c| try eq(abi.code(.ok), c.api.running(c.handle, uid, run)),
        }
    }
    fn returned(self: Driver, uid: u32, run: u64) !void {
        switch (self) {
            .direct => |engine| try engine.reportReturned(uid, run),
            .dynamic => |c| try eq(abi.code(.ok), c.api.returned(c.handle, uid, run)),
        }
    }
    fn shutdown(self: Driver, token: u64) !void {
        switch (self) {
            .direct => |engine| try engine.shutdown(why, if (token == 0) null else token),
            .dynamic => |c| try eq(abi.code(.ok), c.api.shutdown(c.handle, &reason_view, token)),
        }
    }
    fn snapshot(self: Driver, bytes: []u8) !usize {
        return switch (self) {
            .direct => |engine| try engine.snapshot(bytes),
            .dynamic => |c| blk: {
                var needed: usize = 0;
                const result = c.api.snapshot(c.handle, bytes.ptr, bytes.len, &needed);
                try eq(abi.code(if (needed > bytes.len) .buffer_too_small else .ok), result);
                break :blk needed;
            },
        };
    }
};

const Event = struct { kind: enum { start, stop }, uid: u32, run: u64 };
const limits = struct {
    const wait_turns = 5_000_000;
    const events = 64;
    const snapshot_bytes = 65536;
};
const Host = struct {
    mutex: control_sync.Mutex = .{},
    events: [limits.events]Event = undefined,
    count: usize = 0,
    completed: std.atomic.Value(u64) = .init(0),
    changed: std.atomic.Value(u32) = .init(0),
    fn ptr(raw: ?*anyopaque) *Host {
        return @ptrCast(@alignCast(raw.?));
    }
    fn append(self: *Host, queued_event: Event) void {
        self.mutex.lock();
        defer self.mutex.unlock();
        std.debug.assert(self.count < self.events.len);
        self.events[self.count] = queued_event;
        self.count += 1;
    }
    fn onStart(raw: ?*anyopaque, uid: u32, run: u64) callconv(.c) void {
        ptr(raw).append(.{ .kind = .start, .uid = uid, .run = run });
    }
    fn onStop(raw: ?*anyopaque, uid: u32, run: u64) callconv(.c) void {
        ptr(raw).append(.{ .kind = .stop, .uid = uid, .run = run });
    }
    fn onComplete(raw: ?*anyopaque, token: u64) callconv(.c) void {
        ptr(raw).completed.store(token, .release);
    }
    fn onLog(_: ?*anyopaque, _: u32, _: [*]const u8, _: usize) callconv(.c) void {}
    fn onChanged(raw: ?*anyopaque, _: u64, _: abi.ItemKeyView, _: *const abi.ReasonView) callconv(.c) void {
        _ = ptr(raw).changed.fetchAdd(1, .monotonic);
    }
    fn callbacks(self: *Host) control.Host {
        return .{ .context = self, .start = onStart, .stop = onStop, .complete = onComplete, .log = onLog, .item_changed = onChanged };
    }
    fn cCallbacks(self: *Host) abi.HostCallbacks {
        return .{ .context = self, .start = onStart, .stop = onStop, .complete = onComplete, .log = onLog, .item_changed = onChanged };
    }
    fn eventCount(self: *Host) usize {
        self.mutex.lock();
        defer self.mutex.unlock();
        return self.count;
    }
    fn event(self: *Host, index: usize, kind: @FieldType(Event, "kind"), uid: u32) !u64 {
        var turn: usize = 0;
        while (turn < limits.wait_turns) : (turn += 1) {
            self.mutex.lock();
            const found: ?Event = if (index < self.count) self.events[index] else null;
            self.mutex.unlock();
            if (found) |result| {
                try eq(kind, result.kind);
                try eq(uid, result.uid);
                return result.run;
            }
            std.Thread.yield() catch {};
        }
        return error.CallbackTimeout;
    }
    fn completion(self: *Host, token: u64) !void {
        var turn: usize = 0;
        while (turn < limits.wait_turns) : (turn += 1) {
            if (self.completed.load(.acquire) == token) return;
            std.Thread.yield() catch {};
        }
        return error.CompletionTimeout;
    }
};

// Keep the queue's lock in test support; no SDK implementation is duplicated.
const control_sync = struct {
    extern "kernel32" fn AcquireSRWLockExclusive(*usize) callconv(.winapi) void;
    extern "kernel32" fn ReleaseSRWLockExclusive(*usize) callconv(.winapi) void;
    const Mutex = struct {
        value: usize = 0,
        fn lock(self: *Mutex) void {
            AcquireSRWLockExclusive(&self.value);
        }
        fn unlock(self: *Mutex) void {
            ReleaseSRWLockExclusive(&self.value);
        }
    };
};

fn barrier(driver: Driver, host: *Host, claim_value: control.state.Claim, value: bool, token: u64) !void {
    try driver.publish(claim_value, value, token);
    try host.completion(token);
}
fn waitState(driver: Driver, uid: u32, expected: control.BlockState) !void {
    var turn: usize = 0;
    while (turn < limits.wait_turns) : (turn += 1) {
        if (try driver.state(uid) == expected) return;
        std.Thread.yield() catch {};
    }
    return error.StateTimeout;
}

const Scenario = enum { top_down_bottom_up, returned_branch_drains, late_running_old_return };
const Result = struct {
    events: [limits.events]Event = undefined,
    event_count: usize,
    snapshot: []u8,
    fn deinit(self: Result) void {
        std.testing.allocator.free(self.snapshot);
    }
};

fn snapshotProjection(driver: Driver) ![]u8 {
    var short: [1]u8 = undefined;
    const needed = try driver.snapshot(&short);
    try std.testing.expect(needed > short.len and needed <= limits.snapshot_bytes);
    const bytes = try std.testing.allocator.alloc(u8, limits.snapshot_bytes);
    defer std.testing.allocator.free(bytes);
    const written = try driver.snapshot(bytes);
    try std.testing.expect(written <= bytes.len);
    const parsed = try std.json.parseFromSlice(std.json.Value, std.testing.allocator, bytes[0..written], .{});
    defer parsed.deinit();
    const obj = parsed.value.object;
    // Decision history records worker interleavings, so compare the stable
    // externally meaningful snapshot fields and the complete transition trace.
    return std.json.Stringify.valueAlloc(std.testing.allocator, .{
        .registryVersion = obj.get("registryVersion").?,
        .program = obj.get("program").?,
        .shuttingDown = obj.get("shuttingDown").?,
        .blocks = obj.get("blocks").?,
        .transitions = obj.get("transitions").?,
        .items = obj.get("items").?,
        .readers = obj.get("readers").?,
    }, .{});
}

fn runScenario(api: ?*const Api, scenario: Scenario) !Result {
    var host: Host = .{};
    const driver = try Driver.create(api, &host);
    var destroyed = false;
    defer if (!destroyed) cleanup(driver, &host);
    const claim_value = try driver.claim();
    try eq(abi.code(.control_duplicate_claim), driver.duplicateClaimCode());
    try eq(abi.code(.control_unregistered_block), driver.unknownBlockCode());
    try eq(abi.code(.control_not_shutting_down), driver.prematureDestroyCode());
    try driver.publish(claim_value, false, 0);
    try driver.activate();
    try barrier(driver, &host, claim_value, true, 1);
    const first_branch = try host.event(0, .start, B.Branch);
    try eq(@as(u64, 1), first_branch);
    // A parent in starting state cannot start its child, even with true facts.
    try eq(control.BlockState.starting, try driver.state(B.Branch));
    try eq(control.BlockState.stopped, try driver.state(B.Worker));
    try eq(@as(usize, 1), host.eventCount());

    var branch_run = first_branch;
    var worker_run: u64 = undefined;
    var stop_index: usize = undefined;
    if (scenario == .late_running_old_return) {
        try barrier(driver, &host, claim_value, false, 2);
        try eq(first_branch, try host.event(1, .stop, B.Branch));
        try driver.running(B.Branch, first_branch);
        try eq(control.BlockState.stopping, try driver.state(B.Branch));
        try barrier(driver, &host, claim_value, true, 3);
        try eq(@as(usize, 2), host.eventCount());
        try driver.returned(B.Branch, first_branch);
        branch_run = try host.event(2, .start, B.Branch);
        try eq(@as(u64, 2), branch_run);
        try driver.running(B.Branch, branch_run);
        worker_run = try host.event(3, .start, B.Worker);
        try driver.running(B.Worker, worker_run);
        try driver.returned(B.Branch, first_branch);
        try driver.running(B.Branch, first_branch);
        try barrier(driver, &host, claim_value, true, 4);
        try eq(control.BlockState.running, try driver.state(B.Branch));
        try eq(@as(usize, 4), host.eventCount());
        stop_index = 4;
    } else {
        try driver.running(B.Branch, branch_run);
        worker_run = try host.event(1, .start, B.Worker);
        try driver.running(B.Worker, worker_run);
        try barrier(driver, &host, claim_value, true, 2);
        try eq(control.BlockState.running, try driver.state(B.Worker));
        stop_index = 2;
        if (scenario == .returned_branch_drains) {
            const old_worker = worker_run;
            try driver.returned(B.Branch, first_branch);
            try eq(worker_run, try host.event(2, .stop, B.Worker));
            try barrier(driver, &host, claim_value, true, 3);
            try eq(control.BlockState.stopped, try driver.state(B.Branch));
            try eq(control.BlockState.stopping, try driver.state(B.Worker));
            // Revocation must be acknowledged by the whole old branch first.
            try eq(@as(usize, 3), host.eventCount());
            try driver.returned(B.Worker, old_worker);
            branch_run = try host.event(3, .start, B.Branch);
            try eq(@as(u64, 2), branch_run);
            try driver.running(B.Branch, branch_run);
            worker_run = try host.event(4, .start, B.Worker);
            try eq(@as(u64, 2), worker_run);
            try driver.running(B.Worker, worker_run);
            try driver.running(B.Branch, first_branch);
            try driver.returned(B.Branch, first_branch);
            try driver.returned(B.Worker, old_worker);
            try barrier(driver, &host, claim_value, true, 4);
            try eq(control.BlockState.running, try driver.state(B.Branch));
            try eq(control.BlockState.running, try driver.state(B.Worker));
            try eq(@as(usize, 5), host.eventCount());
            stop_index = 5;
        }
    }
    // Shutdown initiates the internal "no longer wanted" handshake. Branch
    // receives no stop until the worker returns, regardless of its own state.
    try driver.shutdown(10);
    try eq(worker_run, try host.event(stop_index, .stop, B.Worker));
    try host.completion(10);
    try eq(control.BlockState.running, try driver.state(B.Branch));
    try eq(control.BlockState.stopping, try driver.state(B.Worker));
    try eq(stop_index + 1, host.eventCount());
    try driver.returned(B.Worker, worker_run);
    try eq(branch_run, try host.event(stop_index + 1, .stop, B.Branch));
    try driver.returned(B.Branch, branch_run);
    try waitState(driver, B.Branch, .stopped);
    try driver.shutdown(11);
    try host.completion(11);
    var result = Result{ .event_count = host.eventCount(), .snapshot = try snapshotProjection(driver) };
    errdefer result.deinit();
    host.mutex.lock();
    @memcpy(result.events[0..result.event_count], host.events[0..result.event_count]);
    host.mutex.unlock();
    try driver.destroy();
    destroyed = true;
    return result;
}

fn cleanup(driver: Driver, host: *Host) void {
    driver.shutdown(0) catch {};
    // Only error cleanup uses this bounded host executor. Process recorded
    // callbacks and acknowledge outstanding runs; it never holds the queue lock
    // while reentering the controller.
    var turn: usize = 0;
    while (turn < limits.wait_turns) : (turn += 1) {
        const worker_state = driver.state(B.Worker) catch .stopped;
        const branch_state = driver.state(B.Branch) catch .stopped;
        if (worker_state == .stopped and branch_state == .stopped) {
            driver.destroy() catch continue;
            return;
        }
        host.mutex.lock();
        var latest: [4]u64 = @splat(0);
        var index: usize = 0;
        while (index < host.count) : (index += 1) latest[host.events[index].uid] = host.events[index].run;
        host.mutex.unlock();
        if (worker_state == .stopping) driver.returned(B.Worker, latest[B.Worker]) catch {};
        if (branch_state == .stopping) driver.returned(B.Branch, latest[B.Branch]) catch {};
        std.Thread.yield() catch {};
    }
    @panic("minimal scenario cleanup timed out");
}

test "minimal product scenarios match direct Zig and dynamically loaded C ABI" {
    const lib = try Library.open();
    defer lib.close();
    const api = try Api.load(lib);
    const scenarios = [_]Scenario{ .top_down_bottom_up, .returned_branch_drains, .late_running_old_return };
    var index: usize = 0;
    while (index < scenarios.len) : (index += 1) {
        const direct = try runScenario(null, scenarios[index]);
        defer direct.deinit();
        const dynamic = try runScenario(&api, scenarios[index]);
        defer dynamic.deinit();
        try eq(direct.event_count, dynamic.event_count);
        var event_index: usize = 0;
        while (event_index < direct.event_count) : (event_index += 1) {
            try std.testing.expectEqualDeep(direct.events[event_index], dynamic.events[event_index]);
        }
        try std.testing.expectEqualStrings(direct.snapshot, dynamic.snapshot);
    }
}
