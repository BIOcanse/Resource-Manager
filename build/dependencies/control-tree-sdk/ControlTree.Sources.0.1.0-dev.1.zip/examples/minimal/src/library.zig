//! This root chooses its own configurations. The SDK knows no consumer UIDs.
const abi = @import("control_tree_abi");
const minimal = @import("minimal");

const Boundary = abi.Exporter(.{
    .{ .id = minimal.options.configuration, .Controller = minimal.Engine },
});

comptime {
    Boundary.exportSymbols();
}
