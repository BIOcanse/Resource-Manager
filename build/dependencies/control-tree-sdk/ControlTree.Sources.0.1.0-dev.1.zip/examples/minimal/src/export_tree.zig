//! Development-only input to the SDK declaration exporter; creates no controller.
const control = @import("control_tree");
const minimal = @import("minimal");

pub const process_name = "minimal";
pub const registry = minimal.registry;
pub const profiles: []const control.export_tree.Profile = &.{
    .{ .name = "minimal", .tree = minimal.topology },
};
