//! The consumer owns the registry, tree and decision functions.
const control = @import("control_tree");
pub const declarations = @import("minimal_state_items");
pub const registry = declarations.registry;
const B = declarations.BlockUids;
const I = declarations.ItemUids;
const C = declarations.ConditionUids;
const parameters = @import("example_options");

fn permitted(input: *control.Input) anyerror!bool {
    // Every no-value reason means this host has not permitted a start.
    return (try input.read(.{ .item = I.HostStartPermitted })).valueOr(false);
}

pub const topology: control.tree.Tree = .{
    .program = B.Program,
    .blocks = &.{
        .{ .uid = B.Program, .parent = null },
        .{ .uid = B.Branch, .parent = B.Program },
        .{ .uid = B.Worker, .parent = B.Branch },
    },
    .uses = &.{},
    .computes = &.{
        .{ .condition = C.StartBranch, .function = permitted },
        .{ .condition = C.StartWorker, .function = permitted },
    },
};

pub const host_block_uids = [_]u32{ B.Branch, B.Worker };
pub const Engine = control.Controller(registry, topology);

/// Visible example parameters, supplied explicitly to either entry path.
pub const options = struct {
    pub const configuration: u32 = 1;
    pub const worker_count = parameters.worker_count;
    pub const history_capacity = parameters.history_capacity;
    pub const completion_capacity = parameters.completion_capacity;
    pub const reader_capacity = parameters.reader_capacity;
    pub const reader_bytes = parameters.reader_bytes;
    pub const worker_arena_bytes = parameters.worker_arena_bytes;
    pub const reason_text_capacity = parameters.reason_text_capacity;
};

pub fn config() control.Config {
    return .{
        .worker_count = options.worker_count,
        .history_capacity = options.history_capacity,
        .completion_capacity = options.completion_capacity,
        .reader_capacity = options.reader_capacity,
        .reader_bytes = options.reader_bytes,
        .worker_arena_bytes = options.worker_arena_bytes,
        .reason_text_capacity = options.reason_text_capacity,
        .shutdown_item = I.IsShuttingDown,
        .host_blocks = &host_block_uids,
    };
}
