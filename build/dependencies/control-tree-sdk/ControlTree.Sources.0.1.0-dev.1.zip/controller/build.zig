const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const control = addModule(b, target, "");
    addTests(b, target, control, "", b.step("test", "Run controller tests"));
}

pub fn addModule(b: *std.Build, target: std.Build.ResolvedTarget, prefix: []const u8) *std.Build.Module {
    // This boundary always retains assertions, including ReleaseFast consumers.
    return b.addModule("control_tree", .{
        .root_source_file = b.path(b.fmt("{s}src/root.zig", .{prefix})),
        .target = target,
        .optimize = .safe,
    });
}

pub fn addTests(b: *std.Build, target: std.Build.ResolvedTarget, control: *std.Build.Module, prefix: []const u8, test_step: *std.Build.Step) void {
    const tests = b.addTest(.{ .root_module = b.createModule(.{
        .root_source_file = b.path(b.fmt("{s}tests/root.zig", .{prefix})),
        .target = target,
        .optimize = .safe,
        .imports = &.{.{ .name = "control_tree", .module = control }},
    }) });
    const run_tests = b.addRunArtifact(tests);
    test_step.dependOn(&run_tests.step);
    const json_tests = b.addTest(.{ .root_module = b.createModule(.{
        .root_source_file = b.path(b.fmt("{s}src/json.zig", .{prefix})),
        .target = target,
        .optimize = .safe,
    }) });
    const run_json_tests = b.addRunArtifact(json_tests);
    test_step.dependOn(&run_json_tests.step);

    const export_tests = b.addTest(.{ .use_llvm = false, .root_module = b.createModule(.{
        .root_source_file = b.path(b.fmt("{s}src/export_tree.zig", .{prefix})),
        .target = target,
        .optimize = .safe,
    }) });
    test_step.dependOn(&b.addRunArtifact(export_tests).step);

    const fixtures = [_]struct { file: []const u8, message: []const u8 }{
        .{ .file = "unknown_parent", .message = "control tree parent is not a registered block" },
        .{ .file = "unknown_input", .message = "control tree input is not a registered block" },
        .{ .file = "missing_block", .message = "control tree must contain every registered block exactly once" },
        .{ .file = "duplicate_block", .message = "control tree must contain every registered block exactly once" },
        .{ .file = "multiple_roots", .message = "control tree root must be the program block" },
        .{ .file = "parent_cycle", .message = "control tree parents contain a cycle" },
        .{ .file = "missing_top", .message = "every direct child must have exactly one top condition" },
        .{ .file = "duplicate_top", .message = "every direct child must have exactly one top condition" },
        .{ .file = "non_direct_top", .message = "top condition must decide a direct child of its node" },
        .{ .file = "non_block_top", .message = "top condition must decide a registered block" },
        .{ .file = "over_limit", .message = "decision node has more than 64 condition instances" },
        .{ .file = "per_block_over_limit", .message = "decision node has more than 64 condition instances" },
        .{ .file = "condition_cycle", .message = "decision node conditions contain a cycle" },
        .{ .file = "host_item_read", .message = "conditions cannot read host-valued items" },
        .{ .file = "unknown_item", .message = "condition reads an unregistered item" },
        .{ .file = "unknown_condition", .message = "condition reads an unregistered condition" },
        .{ .file = "missing_compute", .message = "every condition must have exactly one compute function" },
        .{ .file = "duplicate_compute", .message = "every condition must have exactly one compute function" },
    };
    var fixture_index: usize = 0;
    while (fixture_index < fixtures.len) : (fixture_index += 1) {
        const fixture = fixtures[fixture_index];
        const compile = b.addObject(.{ .name = fixture.file, .root_module = b.createModule(.{
            .root_source_file = b.path(b.fmt("{s}tests/compile_fail/{s}.zig", .{ prefix, fixture.file })),
            .target = target,
            .optimize = .safe,
            .imports = &.{.{ .name = "control_tree", .module = control }},
        }) });
        compile.expect_errors = .{ .contains = fixture.message };
        test_step.dependOn(&compile.step);
    }
    const valid_data_cycle = b.addObject(.{ .name = "valid_data_cycle", .root_module = b.createModule(.{
        .root_source_file = b.path(b.fmt("{s}tests/compile_fail/valid_data_cycle.zig", .{prefix})),
        .target = target,
        .optimize = .fast,
        .imports = &.{.{ .name = "control_tree", .module = control }},
    }) });
    test_step.dependOn(&valid_data_cycle.step);

    const unsafe_control = b.createModule(.{
        .root_source_file = b.path(b.fmt("{s}src/root.zig", .{prefix})),
        .target = target,
        .optimize = .fast,
    });
    const unsafe_test = b.addObject(.{ .name = "unsafe_controller", .root_module = b.createModule(.{
        .root_source_file = b.path(b.fmt("{s}tests/unsafe_controller.zig", .{prefix})),
        .target = target,
        .optimize = .fast,
        .imports = &.{.{ .name = "control_tree", .module = unsafe_control }},
    }) });
    unsafe_test.expect_errors = .{ .contains = "control_tree must compile in ReleaseSafe mode" };
    test_step.dependOn(&unsafe_test.step);
}
