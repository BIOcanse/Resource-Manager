comptime {
    @import("support.zig").check(.missing_block);
}
