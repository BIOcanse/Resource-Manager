const std = @import("std");
const controller_build = @import("controller/build.zig");
const abi_build = @import("abi/build-support.zig");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const names = b.option(bool, "state-names", "Include development registry names and comments") orelse true;
    const powershell = b.option([]const u8, "powershell", "PowerShell 7 executable") orelse "pwsh";
    const control = controller_build.addModule(b, target, "controller/");
    const modules = abi_build.makeModules(b, target, control, names);

    // Validation and generation are one build dependency. Runtime names are
    // selected by build_options in this same generated source.
    const generate = b.addSystemCommand(&.{ powershell, "-NoProfile", "-File" });
    generate.addFileArg(b.path("tools/Generate-StateItems.ps1"));
    generate.addFileInput(b.path("tools/StateItemRegistry.psm1"));
    generate.addArg("-Registry");
    generate.addFileArg(b.path("examples/minimal/registry.json"));
    generate.addArgs(&.{ "-Process", "minimal", "-Language", "Zig", "-Output" });
    modules.state_items.root_source_file = generate.addOutputFileArg("state_items.zig");

    const example = abi_build.addExample(b, target, modules);
    b.installArtifact(example.library);
    b.installFile("abi/include/control_tree.h", "include/control_tree.h");
    const example_step = b.step("example", "Build and install the minimal consumer dynamic library");
    example_step.dependOn(b.getInstallStep());

    const export_run = b.addRunArtifact(example.export_tree);
    b.step("export-tree", "Export minimal development declarations without running the consumer").dependOn(&export_run.step);

    const test_step = b.step("test", "Run controller, C ABI and dynamic-library equivalence tests");
    const controller_step = b.step("test-controller", "Run migrated controller tests and compile-time diagnostics");
    controller_build.addTests(b, target, control, "controller/", controller_step);
    test_step.dependOn(controller_step);
    test_step.dependOn(abi_build.addTests(b, target, modules, example));
}
