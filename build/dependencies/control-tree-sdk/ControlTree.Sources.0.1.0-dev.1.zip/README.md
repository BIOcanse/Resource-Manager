# Control Tree SDK

版本：`0.1.0-dev.1`，Zig `0.17.0`。

控制树管理软件内部长期并发代码块的启动和停止。控制器持有四态、运行编号、条件、状态权威和整支停止握手；业务块保留运行入口和停止处理。控制器只有一份 Zig 实现。

目录：`controller/` 控制器源码和测试，`abi/` 编译期 C 导出层及固定头文件，`tools/` 登记、生成、开发期导出工具，`examples/minimal/` 最小使用方，`scripts/` 打包，`docs/progress.md` 交付状态，`artifacts/sdk/` 包输出（不入库）。

Zig 进程直接导入 `controller/src/root.zig` 为 `control_tree`，该模块必须以 `.optimize = .safe` 编译；使用方模块可使用自己的优化模式。使用方提供生成的登记表和 `tree.Tree`，实例化 `control_tree.Controller(registry, tree)`，创建后再放行。登记表只用工具修改；构建前运行生成器并校验登记。

其他语言使用 `abi/include/control_tree.h` 调用使用方编译出的动态库。使用方用自己的 Zig 根文件把配置号和控制器类型交给 `abi/src/export.zig`；导出层生成固定 `control_tree_` 符号。ABI 版本为 `0x00010000`。配置与树编进动态库，头文件不包含业务声明。

Zig 构建可将本目录作为包依赖，取 `dependency.module("control_tree")` 和 `dependency.module("control_tree_abi")`。不用包管理时，在使用方的 `build.zig` 中创建模块：

```zig
const control = b.createModule(.{
    .root_source_file = .{ .cwd_relative = "<SDK>/controller/src/root.zig" },
    .target = target,
    .optimize = .safe,
});
host_module.addImport("control_tree", control);
```

C 动态库的 Zig 根文件实例化一次导出层：

```zig
const Boundary = @import("control_tree_abi").Exporter(.{
    .{ .id = 1, .Controller = Engine },
});
comptime { Boundary.exportSymbols(); }
```

`Engine` 是使用方的 `Controller(registry, tree)`，导出层从其只读的 `runnable_blocks` 元数据取得预期块 UID。创建配置的 `host_blocks` 仍由宿主声明实际实现的非根块。创建时交五个回调及容量配置，挂好宿主句柄后调用 `control_tree_activate`。回调只排队或置标志并立即返回；宿主报告进入运行和返回时带启动回调给出的运行编号。所有运行返回、程序关闭后再销毁。运行作用域将在 dev.2 提供，本版宿主仍负责报告返回时已经完成所有收尾。

最小使用方见 `examples/minimal/`。在 SDK 根目录：`zig build test example -j1 --summary all` 运行控制器、ABI 布局与边界、直接调用/DLL 一致性测试并产出动态库；`zig build export-tree -j1` 只导出声明。开发期 Zig 构建和测试必须通过 JobQueue 串行执行，示例：

```powershell
& $JobQueue -Action Run -Label 'control-tree test' -FilePath $Zig `
  -ArgumentList @('build','test','example','-j1','--summary','all') `
  -WorkingDirectory $SdkRoot -MemoryLimitGiB 6 -TimeoutMinutes 30
```

`$JobQueue`、`$Zig` 和 `$SdkRoot` 由使用环境指定；`-Dpowershell=<路径>` 可覆盖生成器使用的 PowerShell。`-Dstate-names=false` 编译不带登记名字和注释的声明；开发期导出需要保留名字。

登记、生成和导出使用 PowerShell 7，格式及操作见 [tools/README.md](tools/README.md)。工具行为测试：`pwsh -NoProfile -File tools/tests/Test-Tools.ps1`。

打包：`pwsh -NoProfile -File scripts/Publish-Sdk.ps1 -Version 0.1.0-dev.1 -SourceCommit unknown`。默认输出 `artifacts/sdk/<版本>/`，通过 `-Root`、`-OutputRoot` 可覆盖输入输出位置。输出目录必须尚不存在，重新打包时使用新的 `-OutputRoot`。清单记录源提交、Zig 版本和除清单自身外每个文件的相对路径、长度、SHA-256；第 3.5 节第 3–6 行和 dev.2 能力列入 `unfinished`。

当前控制器同步实现使用 Windows API；本版验证平台为 Windows。计时器、轮询、编译期直连优化、公开外部只读访问、事实环检查和运行作用域尚未实现，详见进度文件。
